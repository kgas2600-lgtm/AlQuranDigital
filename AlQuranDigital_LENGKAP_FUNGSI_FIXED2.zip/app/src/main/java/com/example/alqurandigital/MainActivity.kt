package com.example.alqurandigital

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private val Emerald = Color(0xFF0B6B4F)
private val Deep = Color(0xFF06140F)
private val Surface = Color(0xFF10261E)
private val Surface2 = Color(0xFF17352A)
private val Gold = Color(0xFFD8B15A)
private val White = Color(0xFFF8FBF8)

class QuranViewModel : ViewModel() {
    var surahs by mutableStateOf<List<Surah>>(emptyList())
    var selected by mutableStateOf<SurahDetail?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    init { loadSurahs() }

    fun loadSurahs() = viewModelScope.launch {
        loading = true
        error = null
        try {
            val root = JSONObject(fetchText("https://api.alquran.cloud/v1/surah"))
            val arr = root.getJSONArray("data")
            surahs = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Surah(o.getInt("number"), o.getString("name"), o.getString("englishName"), o.getInt("numberOfAyahs"))
            }
        } catch (_: Exception) { error = "Al-Qur'an belum dapat dimuat. Cek internet." }
        loading = false
    }

    fun openSurah(number: Int) = viewModelScope.launch {
        loading = true
        error = null
        try {
            val root = JSONObject(fetchText("https://api.alquran.cloud/v1/surah/$number/quran-uthmani"))
            val d = root.getJSONObject("data")
            val arr = d.getJSONArray("ayahs")
            val ayahs = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Ayah(o.getInt("number"), o.getString("text"), o.getInt("numberInSurah"))
            }
            selected = SurahDetail(d.getInt("number"), d.getString("name"), d.getString("englishName"), d.getInt("numberOfAyahs"), ayahs)
        } catch (_: Exception) { error = "Surah gagal dimuat. Coba lagi." }
        loading = false
    }
}

data class Surah(val number: Int, val name: String, val englishName: String, val numberOfAyahs: Int)
data class Ayah(val number: Int, val text: String, val numberInSurah: Int)
data class SurahDetail(val number: Int, val name: String, val englishName: String, val numberOfAyahs: Int, val ayahs: List<Ayah>)

suspend fun fetchText(urlString: String): String = withContext(Dispatchers.IO) {
    val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 15000
        readTimeout = 20000
        setRequestProperty("Accept", "application/json")
    }
    try {
        if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
        connection.inputStream.bufferedReader().use { it.readText() }
    } finally { connection.disconnect() }
}

class PrayerViewModel : ViewModel() {
    var times by mutableStateOf<List<Pair<String,String>>>(emptyList())
    var hijri by mutableStateOf("Memuat...")
    var locationName by mutableStateOf("Lokasi belum dipilih")
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    fun loadHijri() = viewModelScope.launch {
        try {
            val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
            val root = JSONObject(fetchText("https://api.aladhan.com/v1/gToH?date=$date"))
            val h = root.getJSONObject("data").getJSONObject("hijri")
            hijri = "${h.getString("day")} ${h.getJSONObject("month").getString("en")} ${h.getString("year")} H"
        } catch (_: Exception) { hijri = "Tanggal Hijriah tidak tersedia" }
    }

    fun load(lat: Double, lon: Double) = viewModelScope.launch {
        loading = true; error = null
        try {
            val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
            val root = JSONObject(fetchText("https://api.aladhan.com/v1/timings/$date?latitude=$lat&longitude=$lon&method=20"))
            val d = root.getJSONObject("data")
            val t = d.getJSONObject("timings")
            val keys = listOf("Fajr" to "Subuh", "Sunrise" to "Terbit", "Dhuhr" to "Zuhur", "Asr" to "Asar", "Maghrib" to "Maghrib", "Isha" to "Isya", "Midnight" to "Tengah Malam")
            times = keys.map { (api, label) -> label to t.optString(api, "--:--").take(5) }
            val h = d.getJSONObject("date").getJSONObject("hijri")
            hijri = "${h.getString("day")} ${h.getJSONObject("month").getString("en")} ${h.getString("year")} H"
        } catch (_: Exception) { error = "Jadwal gagal dimuat. Pastikan lokasi dan internet aktif." }
        loading = false
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranTheme { QuranApp() } }
    }
}

@Composable
fun QuranTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Emerald, secondary = Gold, background = Deep, surface = Surface, onSurface = White), content = content)
}

@Composable
fun QuranApp(quranVm: QuranViewModel = viewModel(), prayerVm: PrayerViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var feature by remember { mutableStateOf<String?>(null) }
    Scaffold(
        containerColor = Deep,
        bottomBar = {
            NavigationBar(containerColor = Surface) {
                val labels = listOf("Beranda", "Al-Qur'an", "Fitur")
                val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Explore)
                labels.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i && feature == null, onClick = { tab = i; feature = null }, icon = { Icon(icons[i], null) }, label = { Text(label) }) }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when {
                quranVm.selected != null -> ReaderScreen(quranVm.selected!!) { quranVm.selected = null }
                feature != null -> when (feature) {
                    "prayer" -> PrayerScreen(prayerVm) { feature = null }
                    "qibla" -> QiblaScreen { feature = null }
                    "tasbih" -> TasbihScreen { feature = null }
                    "doa" -> DoaScreen { feature = null }
                    "calendar" -> HijriScreen(prayerVm) { feature = null }
                }
                tab == 0 -> HomeScreen { tab = 1 }
                tab == 1 -> QuranScreen(quranVm)
                else -> FeatureMenu { feature = it }
            }
        }
    }
}

@Composable
fun HomeScreen(onRead: () -> Unit) {
    val date = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id","ID")).format(Date())
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("السَّلَامُ عَلَيْكُمْ", color = Gold, fontSize = 18.sp); Text("Al-Qur'an Digital", color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text(date, color = Color.LightGray) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(26.dp)) { Column(Modifier.padding(22.dp)) { Text("بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ", color = White, fontSize = 27.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(14.dp)); Text("Baca Al-Qur'an, cek waktu salat, arah kiblat, doa, tasbih, dan kalender Hijriah.", color = White.copy(.9f)); Spacer(Modifier.height(18.dp)); Button(onClick = onRead, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Deep)) { Icon(Icons.Default.MenuBook, null); Spacer(Modifier.width(8.dp)); Text("Mulai Membaca") } } } }
        item { Text("Fitur Utama", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { FeatureCard(Modifier.weight(1f), "🕌", "Salat"); FeatureCard(Modifier.weight(1f), "🧭", "Kiblat"); FeatureCard(Modifier.weight(1f), "📿", "Tasbih"); FeatureCard(Modifier.weight(1f), "🤲", "Doa") } }
    }
}

@Composable fun FeatureCard(modifier: Modifier, icon: String, label: String) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(icon, fontSize = 23.sp); Text(label, color = White, fontSize = 11.sp) } } }

@Composable
fun QuranScreen(vm: QuranViewModel) {
    var search by remember { mutableStateOf("") }
    val filtered = vm.surahs.filter { it.englishName.contains(search, true) || it.name.contains(search, true) || it.number.toString() == search }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Al-Qur'an", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Cari surah atau nomor...") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        vm.error?.let { Text(it, color = Color(0xFFFFB4AB), modifier = Modifier.padding(8.dp)) }
        if (vm.loading && vm.surahs.isEmpty()) Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        LazyColumn(Modifier.fillMaxSize().padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { s -> Card(Modifier.fillMaxWidth().clickable { vm.openSurah(s.number) }, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Surface(shape = RoundedCornerShape(12.dp), color = Emerald) { Text("${s.number}", Modifier.padding(10.dp), color = White) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(s.englishName, color = White, fontWeight = FontWeight.Bold); Text("${s.numberOfAyahs} ayat", color = Color.LightGray, fontSize = 12.sp) }; Text(s.name, color = Gold, fontSize = 21.sp) } } }
        }
    }
}

@Composable
fun ReaderScreen(s: SurahDetail, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("alquran", Context.MODE_PRIVATE) }
    var bookmarks by remember { mutableStateOf(prefs.getStringSet("bookmarks", emptySet()) ?: emptySet()) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }; Column { Text(s.englishName, color = White, fontWeight = FontWeight.Bold); Text("${s.numberOfAyahs} ayat", color = Color.Gray, fontSize = 12.sp) } }
        LazyColumn(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(s.name, color = Gold, fontSize = 30.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp)) }
            itemsIndexed(s.ayahs) { _, a ->
                val key = "${s.number}:${a.numberInSurah}"
                val marked = bookmarks.contains(key)
                Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(a.text, color = White, fontSize = 25.sp, lineHeight = 43.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text("${a.numberInSurah}", color = Gold, fontSize = 12.sp); Spacer(Modifier.weight(1f)); IconButton(onClick = { val set = bookmarks.toMutableSet(); if (marked) set.remove(key) else set.add(key); bookmarks = set; prefs.edit().putStringSet("bookmarks", set).apply() }) { Icon(if (marked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = Gold) }; IconButton(onClick = { val share = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${a.text}\n\nQS ${s.englishName} ayat ${a.numberInSurah}") }; context.startActivity(Intent.createChooser(share, "Bagikan ayat")) }) { Icon(Icons.Default.Share, null) } }
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureMenu(onOpen: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Fitur Muslim", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Semua fitur di bawah dapat digunakan langsung.", color = Color.Gray) }
        val list = listOf("🕌" to ("Jadwal Salat" to "prayer"), "🧭" to ("Arah Kiblat" to "qibla"), "📿" to ("Tasbih Digital" to "tasbih"), "🤲" to ("Doa Harian" to "doa"), "📅" to ("Kalender Hijriah" to "calendar"))
        list.forEach { (icon, pair) -> item { Card(Modifier.fillMaxWidth().clickable { onOpen(pair.second) }, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Text(icon, fontSize = 25.sp); Spacer(Modifier.width(14.dp)); Text(pair.first, color = White, fontSize = 17.sp); Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null) } } } }
    }
}

@Composable
fun PrayerScreen(vm: PrayerViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    var location by remember { mutableStateOf<Location?>(null) }
    var permission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result -> permission = result[Manifest.permission.ACCESS_FINE_LOCATION] == true || result[Manifest.permission.ACCESS_COARSE_LOCATION] == true }
    fun getLocation() {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = lm.getProviders(true)
        var best: Location? = null
        for (p in providers) { try { val l = lm.getLastKnownLocation(p); if (l != null && (best == null || l.accuracy < best!!.accuracy)) best = l } catch (_: SecurityException) {} }
        location = best
        if (best != null) vm.load(best.latitude, best.longitude) else vm.error = "Lokasi belum tersedia. Nyalakan GPS lalu coba lagi."
    }
    LaunchedEffect(permission) { if (permission) getLocation() }
    SimplePage("🕌 Jadwal Salat", onBack) {
        Text(vm.hijri, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(if (location != null) "Lokasi: ${location!!.latitude.format(3)}, ${location!!.longitude.format(3)}" else "Lokasi belum tersedia", color = Color.Gray)
        if (!permission) Button(onClick = { launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) { Icon(Icons.Default.LocationOn, null); Spacer(Modifier.width(6.dp)); Text("Izinkan Lokasi") }
        else OutlinedButton(onClick = { getLocation() }) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Perbarui Jadwal") }
        vm.error?.let { Text(it, color = Color(0xFFFFB4AB)) }
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.times.forEach { (name, time) -> PrayerRow(name, time) }
        Text("Metode perhitungan: Muslim World League (API AlAdhan).", color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable fun PrayerRow(name: String, time: String) { Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(14.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(name, color = White, modifier = Modifier.weight(1f)); Text(time, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp) } } }

@Composable
fun QiblaScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var permission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) }
    var qibla by remember { mutableFloatStateOf(0f) }
    var heading by remember { mutableFloatStateOf(0f) }
    var lat by remember { mutableStateOf<Double?>(null) }; var lon by remember { mutableStateOf<Double?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> permission = r[Manifest.permission.ACCESS_FINE_LOCATION] == true || r[Manifest.permission.ACCESS_COARSE_LOCATION] == true }
    fun updateLocation() { if (!permission) return; val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager; try { val l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER); if (l != null) { lat = l.latitude; lon = l.longitude; qibla = bearingToKaaba(l.latitude, l.longitude) } } catch (_: SecurityException) {} }
    LaunchedEffect(permission) { if (permission) updateLocation() }
    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotation = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val listener = object : SensorEventListener {
            private val rm = FloatArray(9); private val ori = FloatArray(3)
            override fun onSensorChanged(e: SensorEvent) { if (e.sensor.type == Sensor.TYPE_ROTATION_VECTOR) { SensorManager.getRotationMatrixFromVector(rm, e.values); SensorManager.getOrientation(rm, ori); heading = ((Math.toDegrees(ori[0].toDouble()) + 360) % 360).toFloat() } }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (rotation != null) sm.registerListener(listener, rotation, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(listener) }
    }
    val relative = ((qibla - heading + 360) % 360)
    SimplePage("🧭 Arah Kiblat", onBack) {
        if (!permission) Button(onClick = { launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)) }) { Icon(Icons.Default.LocationOn, null); Spacer(Modifier.width(6.dp)); Text("Izinkan Lokasi") }
        else OutlinedButton(onClick = { updateLocation() }) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Perbarui Lokasi") }
        Box(Modifier.fillMaxWidth().height(280.dp), contentAlignment = Alignment.Center) {
            Surface(Modifier.size(220.dp), shape = CircleShape, color = Surface2) { Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) { Text("N", color = Gold, fontSize = 20.sp, modifier = Modifier.align(Alignment.TopCenter).padding(18.dp)); Text("🕋", fontSize = 55.sp, modifier = Modifier.rotate(relative)); Text("Arah ${relative.toInt()}°", color = White, modifier = Modifier.align(Alignment.BottomCenter).padding(18.dp)) } }
        }
        Text("Kiblat: ${qibla.toInt()}° dari utara", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(if (lat != null) "Koordinat: ${lat!!.format(4)}, ${lon!!.format(4)}" else "Lokasi belum tersedia", color = Color.Gray)
        Text("Putar perangkat sampai simbol 🕋 mengarah ke depan.", color = Color.LightGray)
    }
}

fun bearingToKaaba(lat: Double, lon: Double): Float {
    val kaabaLat = Math.toRadians(21.422487); val kaabaLon = Math.toRadians(39.826206); val p1 = Math.toRadians(lat); val l1 = Math.toRadians(lon); val dl = kaabaLon - l1
    return ((Math.toDegrees(atan2(sin(dl), cos(p1) * tan(kaabaLat) - sin(p1) * cos(dl))) + 360) % 360).toFloat()
}

@Composable
fun TasbihScreen(onBack: () -> Unit) {
    val context = LocalContext.current; val prefs = remember { context.getSharedPreferences("tasbih", Context.MODE_PRIVATE) }
    var count by remember { mutableIntStateOf(prefs.getInt("count", 0)) }; var target by remember { mutableIntStateOf(prefs.getInt("target", 33)) }; var phrase by remember { mutableStateOf(prefs.getString("phrase", "سُبْحَانَ اللَّهِ") ?: "سُبْحَانَ اللَّهِ") }
    fun save() = prefs.edit().putInt("count", count).putInt("target", target).putString("phrase", phrase).apply()
    SimplePage("📿 Tasbih Digital", onBack) {
        Text(phrase, color = Gold, fontSize = 25.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text("$count", color = White, fontSize = 70.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text("Target $target", color = Color.Gray, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Button(onClick = { count = if (count >= target) 0 else count + 1; save() }, modifier = Modifier.fillMaxWidth().height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = Emerald)) { Text("TASBIH", fontSize = 20.sp) }
        OutlinedButton(onClick = { count = 0; save() }, modifier = Modifier.fillMaxWidth()) { Text("Reset") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(33, 99, 100).forEach { n -> FilterChip(selected = target == n, onClick = { target = n; count = 0; save() }, label = { Text("$n") }) } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("سُبْحَانَ اللَّهِ", "الْحَمْدُ لِلَّهِ", "اللَّهُ أَكْبَرُ").forEach { p -> FilterChip(selected = phrase == p, onClick = { phrase = p; save() }, label = { Text(p, fontSize = 11.sp) }) } }
    }
}

@Composable
fun DoaScreen(onBack: () -> Unit) {
    val doa = listOf(
        "Doa sebelum makan" to ("بِسْمِ اللَّهِ" to "Dengan nama Allah."),
        "Doa setelah makan" to ("الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا" to "Segala puji bagi Allah yang telah memberiku makanan ini."),
        "Doa masuk rumah" to ("بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا" to "Dengan nama Allah kami masuk dan dengan nama Allah kami keluar."),
        "Doa keluar rumah" to ("بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ" to "Dengan nama Allah, aku bertawakal kepada Allah."),
        "Doa sebelum tidur" to ("بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا" to "Dengan nama-Mu ya Allah, aku mati dan aku hidup."),
        "Doa bangun tidur" to ("الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا" to "Segala puji bagi Allah yang menghidupkan kami."),
        "Doa untuk kedua orang tua" to ("رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا" to "Wahai Tuhanku, sayangilah keduanya sebagaimana mereka menyayangiku ketika kecil."),
        "Doa memohon ilmu" to ("رَبِّ زِدْنِي عِلْمًا" to "Ya Tuhanku, tambahkanlah aku ilmu."),
        "Doa kebaikan dunia akhirat" to ("رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً" to "Ya Tuhan kami, berilah kami kebaikan di dunia dan akhirat.")
    )
    SimplePage("🤲 Doa Harian", onBack) { doa.forEach { (title, pair) -> Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(18.dp)) { Text(title, color = Gold, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(pair.first, color = White, fontSize = 23.sp, lineHeight = 38.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(8.dp)); Text(pair.second, color = Color.LightGray) } } } }
}

@Composable
fun HijriScreen(vm: PrayerViewModel, onBack: () -> Unit) {
    val date = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID")).format(Date())
    LaunchedEffect(Unit) { vm.loadHijri() }
    SimplePage("📅 Kalender Hijriah", onBack) {
        Text("Hari ini", color = Color.Gray)
        Text(date, color = White, fontSize = 23.sp)
        Text(vm.hijri, color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Kalender Hijriah", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Konversi tanggal Masehi ke Hijriah diperbarui dari layanan AlAdhan.", color = Color.LightGray)
                Spacer(Modifier.height(8.dp))
                Text("Catatan: awal bulan Hijriah dapat berbeda menurut metode/rukyah setempat.", color = Color.Gray, fontSize = 12.sp)
            }
        }
        OutlinedButton(onClick = { vm.loadHijri() }) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Perbarui Tanggal") }
    }
}

@Composable
fun SimplePage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }; Text(title, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

fun Double.format(decimals: Int): String = String.format(Locale.US, "%.${decimals}f", this)
