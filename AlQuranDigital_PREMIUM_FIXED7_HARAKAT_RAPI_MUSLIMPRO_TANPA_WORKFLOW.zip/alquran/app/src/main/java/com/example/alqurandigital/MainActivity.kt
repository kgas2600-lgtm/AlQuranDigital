package com.example.alqurandigital

private fun tidyArabic(text: String): String {
    return Normalizer.normalize(text, Normalizer.Form.NFC)
        .replace(Regex("[\\u200B-\\u200F\\u202A-\\u202E]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
}

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.text.Normalizer
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private val Emerald = Color(0xFF0B6B4F)
private val Deep = Color(0xFF06140F)
private val Surface = Color(0xFF10261E)
private val Surface2 = Color(0xFF17352A)
private val Gold = Color(0xFFD8B15A)
private val White = Color(0xFFF8FBF8)

class QuranViewModel : ViewModel() {
    var surahs by mutableStateOf<List<Surah>>(emptyList())
    var selected by mutableStateOf<SurahDetail?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    init { loadSurahs() }

    fun loadSurahs() = viewModelScope.launch {
        loading = true
        error = null
        try {
            val root = JSONObject(fetchText("https://api.alquran.cloud/v1/surah"))
            val arr = root.getJSONArray("data")
            surahs = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Surah(o.getInt("number"), o.getString("name"), o.getString("englishName"), o.getInt("numberOfAyahs"))
            }
        } catch (_: Exception) { error = "Al-Qur'an belum dapat dimuat. Cek internet." }
        loading = false
    }

    fun openSurah(number: Int) = viewModelScope.launch {
        loading = true
        error = null
        try {
            val root = JSONObject(fetchText("https://api.alquran.cloud/v1/surah/$number/quran-uthmani"))
            val d = root.getJSONObject("data")
            val arr = d.getJSONArray("ayahs")
            val ayahs = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Ayah(o.getInt("number"), o.getString("text"), o.getInt("numberInSurah"))
            }
            selected = SurahDetail(d.getInt("number"), d.getString("name"), d.getString("englishName"), d.getInt("numberOfAyahs"), ayahs)
        } catch (_: Exception) { error = "Surah gagal dimuat. Coba lagi." }
        loading = false
    }
}

data class Surah(val number: Int, val name: String, val englishName: String, val numberOfAyahs: Int)
data class Ayah(val number: Int, val text: String, val numberInSurah: Int)
data class SurahDetail(val number: Int, val name: String, val englishName: String, val numberOfAyahs: Int, val ayahs: List<Ayah>)

suspend fun fetchText(urlString: String): String = withContext(Dispatchers.IO) {
    val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 15000
        readTimeout = 20000
        setRequestProperty("Accept", "application/json")
    }
    try {
        if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
        connection.inputStream.bufferedReader().use { it.readText() }
    } finally { connection.disconnect() }
}

class PrayerViewModel : ViewModel() {
    var times by mutableStateOf<List<Pair<String,String>>>(emptyList())
    var hijri by mutableStateOf("Memuat...")
    var locationName by mutableStateOf("Lokasi belum dipilih")
    var timezone by mutableStateOf("Zona waktu mengikuti lokasi")
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    fun loadHijri() = viewModelScope.launch {
        try {
            val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
            val root = JSONObject(fetchText("https://api.aladhan.com/v1/gToH?date=$date"))
            val h = root.getJSONObject("data").getJSONObject("hijri")
            hijri = "${h.getString("day")} ${h.getJSONObject("month").getString("en")} ${h.getString("year")} H"
        } catch (_: Exception) { hijri = "Tanggal Hijriah tidak tersedia" }
    }

    fun load(lat: Double, lon: Double) = viewModelScope.launch {
        loading = true; error = null
        try {
            val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
            val root = JSONObject(fetchText("https://api.aladhan.com/v1/timings/$date?latitude=$lat&longitude=$lon&method=20&school=0&midnightMode=0"))
            val d = root.getJSONObject("data")
            timezone = root.getJSONObject("data").getJSONObject("meta").optString("timezone", "Zona waktu mengikuti lokasi")
            val t = d.getJSONObject("timings")
            val keys = listOf("Fajr" to "Subuh", "Sunrise" to "Terbit", "Dhuhr" to "Zuhur", "Asr" to "Asar", "Maghrib" to "Maghrib", "Isha" to "Isya")
            times = keys.map { (api, label) -> label to t.optString(api, "--:--").take(5) }
            val h = d.getJSONObject("date").getJSONObject("hijri")
            hijri = "${h.getString("day")} ${h.getJSONObject("month").getString("en")} ${h.getString("year")} H"
        } catch (_: Exception) { error = "Jadwal gagal dimuat. Pastikan lokasi dan internet aktif." }
        loading = false
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranTheme { QuranApp() } }
    }
}

@Composable
fun QuranTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Emerald, secondary = Gold, background = Deep, surface = Surface, onSurface = White), content = content)
}

@Composable
fun QuranApp(quranVm: QuranViewModel = viewModel(), prayerVm: PrayerViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var feature by remember { mutableStateOf<String?>(null) }
    Scaffold(
        containerColor = Deep,
        bottomBar = {
            NavigationBar(containerColor = Surface) {
                val labels = listOf("Beranda", "Al-Qur'an", "Fitur")
                val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Explore)
                labels.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i && feature == null, onClick = { tab = i; feature = null }, icon = { Icon(icons[i], null) }, label = { Text(label) }) }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when {
                quranVm.selected != null -> ReaderScreen(quranVm.selected!!) { quranVm.selected = null }
                feature != null -> when (feature) {
                    "prayer" -> PrayerScreen(prayerVm) { feature = null }
                    "qibla" -> QiblaScreen { feature = null }
                    "tasbih" -> TasbihScreen { feature = null }
                    "doa" -> DoaScreen { feature = null }
                    "calendar" -> HijriScreen(prayerVm) { feature = null }
                }
                tab == 0 -> HomeScreen { tab = 1 }
                tab == 1 -> QuranScreen(quranVm)
                else -> FeatureMenu { feature = it }
            }
        }
    }
}

@Composable
fun HomeScreen(onRead: () -> Unit) {
    val date = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id","ID")).format(Date())
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("السَّلَامُ عَلَيْكُمْ", color = Gold, fontSize = 18.sp); Text("Al-Qur'an Digital", color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text(date, color = Color.LightGray) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(26.dp)) { Column(Modifier.padding(22.dp)) { Text("بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ", color = White, fontSize = 27.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(14.dp)); Text("Baca Al-Qur'an, cek waktu salat, arah kiblat, doa, tasbih, dan kalender Hijriah.", color = White.copy(.9f)); Spacer(Modifier.height(18.dp)); Button(onClick = onRead, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Deep)) { Icon(Icons.Default.MenuBook, null); Spacer(Modifier.width(8.dp)); Text("Mulai Membaca") } } } }
        item { Text("Fitur Utama", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { FeatureCard(Modifier.weight(1f), "🕌", "Salat"); FeatureCard(Modifier.weight(1f), "🧭", "Kiblat"); FeatureCard(Modifier.weight(1f), "📿", "Tasbih"); FeatureCard(Modifier.weight(1f), "🤲", "Doa") } }
    }
}

@Composable fun FeatureCard(modifier: Modifier, icon: String, label: String) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(icon, fontSize = 23.sp); Text(label, color = White, fontSize = 11.sp) } } }

@Composable
fun QuranScreen(vm: QuranViewModel) {
    var search by remember { mutableStateOf("") }
    val filtered = vm.surahs.filter { it.englishName.contains(search, true) || it.name.contains(search, true) || it.number.toString() == search }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Al-Qur'an", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Cari surah atau nomor...") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        vm.error?.let { Text(it, color = Color(0xFFFFB4AB), modifier = Modifier.padding(8.dp)) }
        if (vm.loading && vm.surahs.isEmpty()) Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        LazyColumn(Modifier.fillMaxSize().padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { s -> Card(Modifier.fillMaxWidth().clickable { vm.openSurah(s.number) }, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Surface(shape = RoundedCornerShape(12.dp), color = Emerald) { Text("${s.number}", Modifier.padding(10.dp), color = White) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(s.englishName, color = White, fontWeight = FontWeight.Bold); Text("${s.numberOfAyahs} ayat", color = Color.LightGray, fontSize = 12.sp) }; Text(s.name, color = Gold, fontSize = 21.sp) } } }
        }
    }
}

private const val BISMILLAH = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ"

private fun removeLeadingBismillah(text: String): String {
    val original = text.replace("\uFEFF", "").trim()
    fun plainArabic(value: String): String = value
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        .replace("\\u0640", "")
        .replace(Regex("\\s+"), "")
        .trim()

    val target = plainArabic(BISMILLAH)
    val originalChars = original.toCharArray()
    var i = 0
    var j = 0
    while (i < originalChars.size && j < target.length) {
        val c = originalChars[i]
        if (c.isWhitespace() || c in '\u064B'..'\u065F' || c == '\u0670' || c == '\u0640') {
            i++
            continue
        }
        if (c != target[j]) return original
        i++
        j++
    }
    return if (j == target.length) original.substring(i).trim() else original
}

@Composable
fun ReaderScreen(s: SurahDetail, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("alquran", Context.MODE_PRIVATE) }
    var bookmarks by remember { mutableStateOf(prefs.getStringSet("bookmarks", emptySet()) ?: emptySet()) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Column { Text(s.englishName, color = White, fontWeight = FontWeight.Bold); Text("${s.numberOfAyahs} ayat", color = Color.Gray, fontSize = 12.sp) }
        }
        LazyColumn(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(s.name, color = Gold, fontSize = 30.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp)) }
            items(s.ayahs) { a ->
                val key = "${s.number}:${a.numberInSurah}"
                val marked = bookmarks.contains(key)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (a.numberInSurah == 1 && s.number != 9) {
                        Card(colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(18.dp)) {
                            Text(BISMILLAH, color = Gold, fontSize = 28.sp, lineHeight = 52.sp, fontFamily = FontFamily.Serif, letterSpacing = 0.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(18.dp))
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            val displayedAyah = if (a.numberInSurah == 1 && s.number != 9) removeLeadingBismillah(a.text) else a.text
                            Text(displayedAyah, color = White, fontSize = 28.sp, lineHeight = 52.sp, fontFamily = FontFamily.Serif, letterSpacing = 0.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${a.numberInSurah}", color = Gold, fontSize = 12.sp)
                                Spacer(Modifier.weight(1f))
                                IconButton(onClick = { val set = bookmarks.toMutableSet(); if (marked) set.remove(key) else set.add(key); bookmarks = set; prefs.edit().putStringSet("bookmarks", set).apply() }) {
                                    Icon(if (marked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = Gold)
                                }
                                IconButton(onClick = { val share = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${displayedAyah}\n\nQS ${s.englishName} ayat ${a.numberInSurah}") }; context.startActivity(Intent.createChooser(share, "Bagikan ayat")) }) {
                                    Icon(Icons.Default.Share, null)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
@Composable
fun FeatureMenu(onOpen: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Fitur Muslim", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Semua fitur di bawah dapat digunakan langsung.", color = Color.Gray) }
        val list = listOf("🕌" to ("Jadwal Salat" to "prayer"), "🧭" to ("Arah Kiblat" to "qibla"), "📿" to ("Tasbih Digital" to "tasbih"), "🤲" to ("Doa Harian" to "doa"), "📅" to ("Kalender Hijriah" to "calendar"))
        list.forEach { (icon, pair) -> item { Card(Modifier.fillMaxWidth().clickable { onOpen(pair.second) }, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Text(icon, fontSize = 25.sp); Spacer(Modifier.width(14.dp)); Text(
                        tidyArabic(pair.first),
color = White, fontSize = 17.sp); Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null) } } } }
    }
}

@Composable
fun PrayerScreen(vm: PrayerViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }
    val muslimProUrl = "https://app.muslimpro.com/id/prayer-times/indonesia/jakarta-prayer-times/1642911"

    SimplePage("🕌 Jadwal Salat", onBack) {
        Text("Jadwal Salat dari Muslim Pro", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Sumber waktu salat: situs resmi Muslim Pro. Jadwal mengikuti data lokasi Jakarta.", color = Color.LightGray, fontSize = 13.sp)
        OutlinedButton(onClick = { webView?.reload() }) {
            Icon(Icons.Default.Refresh, null)
            Spacer(Modifier.width(6.dp))
            Text("Perbarui Jadwal")
        }
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { ctx ->
                WebView(ctx).apply {
                    webView = this
                    webViewClient = WebViewClient()
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    loadUrl(muslimProUrl)
                }
            },
            update = { webView = it }
        )
    }
}
@Composable fun PrayerRow(name: String, time: String) { Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(14.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(name, color = White, modifier = Modifier.weight(1f)); Text(time, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp) } } }

@Composable
fun QiblaScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var permission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    var qibla by remember { mutableFloatStateOf(0f) }
    var heading by remember { mutableFloatStateOf(0f) }
    var lat by remember { mutableStateOf<Double?>(null) }
    var lon by remember { mutableStateOf<Double?>(null) }
    var sensorReady by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permission =
            result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    fun updateLocation() {
        if (!permission) return
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            val location =
                lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (location != null) {
                lat = location.latitude
                lon = location.longitude
                qibla = bearingToKaaba(location.latitude, location.longitude)
            }
        } catch (_: SecurityException) {
        }
    }

    LaunchedEffect(permission) {
        if (permission) updateLocation()
    }

    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotation = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val listener = object : SensorEventListener {
            private val rotationMatrix = FloatArray(9)
            private val orientation = FloatArray(3)

            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                SensorManager.getOrientation(rotationMatrix, orientation)
                heading = ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
                sensorReady = true
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        if (rotation != null) {
            sm.registerListener(listener, rotation, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { sm.unregisterListener(listener) }
    }

    val relative = ((qibla - heading + 540f) % 360f) - 180f
    val aligned = kotlin.math.abs(relative) <= 8f

    SimplePage("🧭 Arah Kiblat", onBack) {
        Text(
            "Kiblat jadi mudah",
            color = Gold,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Izinkan lokasi, lalu putar HP sampai panah menunjuk ke arah Ka'bah.",
            color = Color.LightGray,
            fontSize = 14.sp,
            lineHeight = 21.sp
        )

        if (!permission) {
            Button(
                onClick = {
                    launcher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Emerald)
            ) {
                Icon(Icons.Default.LocationOn, null)
                Spacer(Modifier.width(8.dp))
                Text("Izinkan Lokasi")
            }
        } else {
            OutlinedButton(
                onClick = { updateLocation() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("Perbarui Lokasi")
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Surface2),
            shape = RoundedCornerShape(26.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    if (aligned) "✓ Menghadap Kiblat" else "Arahkan ke Kiblat",
                    color = if (aligned) Gold else White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                Box(
                    modifier = Modifier.size(240.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        shape = CircleShape,
                        color = Deep
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                "N",
                                color = Gold,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopCenter).padding(top = 14.dp)
                            )
                            Text(
                                "↑",
                                color = Gold,
                                fontSize = 86.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.rotate(relative)
                            )
                            Text(
                                "🕋",
                                fontSize = 31.sp,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "${kotlin.math.round(relative).toInt()}°",
                    color = White,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "putar HP mengikuti arah panah",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Surface),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Status", color = Gold, fontWeight = FontWeight.Bold)
                Text(
                    if (lat != null) "Lokasi: ${lat!!.format(4)}, ${lon!!.format(4)}"
                    else "Lokasi belum tersedia — tekan Perbarui Lokasi.",
                    color = White
                )
                Text(
                    if (sensorReady) "Sensor kompas: aktif" else "Sensor kompas: belum tersedia",
                    color = if (sensorReady) Color.LightGray else Gold,
                    fontSize = 13.sp
                )
                Text(
                    if (qibla > 0f) "Arah Kiblat: ${qibla.toInt()}° dari utara"
                    else "Arah Kiblat: menunggu lokasi",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            }
        }

        Text(
            "Tips: jauhkan HP dari magnet, casing magnet, atau benda logam saat mengkalibrasi kompas.",
            color = Color.Gray,
            fontSize = 12.sp,
            lineHeight = 18.sp
        )
    }
}

fun bearingToKaaba(lat: Double, lon: Double): Float {
    val kaabaLat = Math.toRadians(21.422487); val kaabaLon = Math.toRadians(39.826206); val p1 = Math.toRadians(lat); val l1 = Math.toRadians(lon); val dl = kaabaLon - l1
    return ((Math.toDegrees(Math.atan2(Math.sin(dl), Math.cos(p1) * Math.tan(kaabaLat) - Math.sin(p1) * Math.cos(dl))) + 360) % 360).toFloat()
}

@Composable
fun TasbihScreen(onBack: () -> Unit) {
    val context = LocalContext.current; val prefs = remember { context.getSharedPreferences("tasbih", Context.MODE_PRIVATE) }
    var count by remember { mutableIntStateOf(prefs.getInt("count", 0)) }; var target by remember { mutableIntStateOf(prefs.getInt("target", 33)) }; var phrase by remember { mutableStateOf(prefs.getString("phrase", "سُبْحَانَ اللَّهِ") ?: "سُبْحَانَ اللَّهِ") }
    fun save() = prefs.edit().putInt("count", count).putInt("target", target).putString("phrase", phrase).apply()
    SimplePage("📿 Tasbih Digital", onBack) {
        Text(phrase, color = Gold, fontSize = 25.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text("$count", color = White, fontSize = 70.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text("Target $target", color = Color.Gray, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Button(onClick = { count = if (count >= target) 0 else count + 1; save() }, modifier = Modifier.fillMaxWidth().height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = Emerald)) { Text("TASBIH", fontSize = 20.sp) }
        OutlinedButton(onClick = { count = 0; save() }, modifier = Modifier.fillMaxWidth()) { Text("Reset") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(33, 99, 100).forEach { n -> FilterChip(selected = target == n, onClick = { target = n; count = 0; save() }, label = { Text("$n") }) } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("سُبْحَانَ اللَّهِ", "الْحَمْدُ لِلَّهِ", "اللَّهُ أَكْبَرُ").forEach { p -> FilterChip(selected = phrase == p, onClick = { phrase = p; save() }, label = { Text(p, fontSize = 11.sp) }) } }
    }
}

@Composable
fun DoaScreen(onBack: () -> Unit) {
    val doa = listOf(
        "Doa sebelum makan" to ("بِسْمِ اللَّهِ" to "Dengan nama Allah."),
        "Doa ketika lupa membaca sebelum makan" to ("بِسْمِ اللَّهِ أَوَّلَهُ وَآخِرَهُ" to "Dengan nama Allah pada awal dan akhirnya."),
        "Doa setelah makan" to ("الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ" to "Segala puji bagi Allah yang telah memberiku makanan ini dan memberiku rezeki tanpa daya dan kekuatan dariku."),
        "Doa masuk rumah" to ("بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا" to "Dengan nama Allah kami masuk, dengan nama Allah kami keluar, dan kepada Allah Tuhan kami, kami bertawakal."),
        "Doa keluar rumah" to ("بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ" to "Dengan nama Allah, aku bertawakal kepada Allah. Tidak ada daya dan kekuatan kecuali dengan pertolongan Allah."),
        "Doa sebelum tidur" to ("بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا" to "Dengan nama-Mu, ya Allah, aku mati dan aku hidup."),
        "Doa bangun tidur" to ("الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ" to "Segala puji bagi Allah yang telah menghidupkan kami setelah mematikan kami dan kepada-Nya kami kembali."),
        "Doa untuk kedua orang tua" to ("رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا" to "Ya Tuhanku, sayangilah keduanya sebagaimana mereka telah menyayangiku ketika aku masih kecil."),
        "Doa memohon ilmu" to ("رَبِّ زِدْنِي عِلْمًا" to "Ya Tuhanku, tambahkanlah kepadaku ilmu."),
        "Doa kebaikan dunia dan akhirat" to ("رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ" to "Ya Tuhan kami, berilah kami kebaikan di dunia dan kebaikan di akhirat serta lindungilah kami dari azab neraka."),
        "Doa masuk masjid" to ("اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ" to "Ya Allah, bukakanlah untukku pintu-pintu rahmat-Mu."),
        "Doa keluar masjid" to ("اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ" to "Ya Allah, sesungguhnya aku memohon kepada-Mu karunia-Mu."),
        "Doa masuk kamar mandi" to ("اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ" to "Ya Allah, sesungguhnya aku berlindung kepada-Mu dari setan laki-laki dan setan perempuan."),
        "Doa keluar kamar mandi" to ("غُفْرَانَكَ" to "Aku memohon ampun kepada-Mu."),
        "Doa sebelum wudu" to ("بِسْمِ اللَّهِ" to "Dengan nama Allah."),
        "Doa setelah wudu" to ("أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ" to "Aku bersaksi bahwa tidak ada Tuhan yang berhak disembah selain Allah, Yang Maha Esa dan tidak memiliki sekutu. Aku bersaksi bahwa Muhammad adalah hamba dan utusan-Nya."),
        "Doa memohon ampun" to ("رَبِّ اغْفِرْ لِي وَتُبْ عَلَيَّ إِنَّكَ أَنْتَ التَّوَّابُ الرَّحِيمُ" to "Ya Tuhanku, ampunilah aku dan terimalah tobatku. Sesungguhnya Engkau Maha Penerima Tobat lagi Maha Penyayang.")
    )

    SimplePage("🤲 Doa Harian", onBack) {
        Text(
            "Doa pilihan dengan tulisan Arab yang lebih rapi",
            color = Color.LightGray,
            fontSize = 14.sp
        )
        doa.forEachIndexed { index, (title, pair) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Surface),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            modifier = Modifier.size(32.dp),
                            shape = CircleShape,
                            color = Surface2
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("${index + 1}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        tidyArabic(pair.first),
color = White,
                        fontSize = 25.sp,
                        lineHeight = 47.sp,
                        fontFamily = FontFamily.Serif,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(pair.second, color = Color.LightGray, fontSize = 14.sp, lineHeight = 21.sp)
                }
            }
        }
    }
}

@Composable
fun HijriScreen(vm: PrayerViewModel, onBack: () -> Unit) {
    val date = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID")).format(Date())
    LaunchedEffect(Unit) { vm.loadHijri() }
    SimplePage("📅 Kalender Hijriah", onBack) {
        Text("Hari ini", color = Color.Gray)
        Text(date, color = White, fontSize = 23.sp)
        Text(vm.hijri, color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Kalender Hijriah", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Konversi tanggal Masehi ke Hijriah diperbarui dari layanan AlAdhan.", color = Color.LightGray)
                Spacer(Modifier.height(8.dp))
                Text("Catatan: awal bulan Hijriah dapat berbeda menurut metode/rukyah setempat.", color = Color.Gray, fontSize = 12.sp)
            }
        }
        OutlinedButton(onClick = { vm.loadHijri() }) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Perbarui Tanggal") }
    }
}

@Composable
fun SimplePage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Deep)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = White)
            }
            Text(
                title,
                color = White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Column(
            Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

fun Double.format(decimals: Int): String = String.format(Locale.US, "%.${decimals}f", this)
