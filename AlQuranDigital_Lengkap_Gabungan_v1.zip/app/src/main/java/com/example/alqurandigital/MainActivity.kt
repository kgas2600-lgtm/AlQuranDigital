package com.example.alqurandigital

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.android.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import java.text.SimpleDateFormat
import java.util.*

private val Emerald = Color(0xFF0B6B4F)
private val Deep = Color(0xFF06140F)
private val Surface = Color(0xFF10261E)
private val Gold = Color(0xFFD8B15A)

@Serializable
data class Surah(val number:Int, val name:String, val englishName:String, val numberOfAyahs:Int)

@Serializable
data class Ayah(val number:Int, val text:String, val numberInSurah:Int)

@Serializable
data class SurahDetail(
    val number:Int,
    val name:String,
    val englishName:String,
    val numberOfAyahs:Int,
    val ayahs:List<Ayah>
)

@Serializable
data class ApiResponse<T>(val code:Int, val status:String, val data:T)

class QuranViewModel : ViewModel() {
    private val client = HttpClient(Android) {
        install(ContentNegotiation) { json() }
    }

    var surahs by mutableStateOf<List<Surah>>(emptyList())
    var selected by mutableStateOf<SurahDetail?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    init { loadSurahs() }

    fun loadSurahs() = viewModelScope.launch {
        loading = true
        try {
            surahs = client.get("https://api.alquran.cloud/v1/surah")
                .body<ApiResponse<List<Surah>>>().data
        } catch (e: Exception) {
            error = "Tidak dapat memuat Al-Qur'an. Periksa internet."
        }
        loading = false
    }

    fun openSurah(number:Int) = viewModelScope.launch {
        loading = true
        try {
            selected = client.get("https://api.alquran.cloud/v1/surah/$number/quran-uthmani")
                .body<ApiResponse<SurahDetail>>().data
        } catch (e: Exception) {
            error = "Surah gagal dimuat."
        }
        loading = false
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranTheme { QuranApp() } }
    }
}

@Composable
fun QuranTheme(content:@Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Emerald,
            secondary = Gold,
            background = Deep,
            surface = Surface
        ),
        content = content
    )
}

@Composable
fun QuranApp(vm:QuranViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }

    Scaffold(
        containerColor = Deep,
        bottomBar = {
            NavigationBar(containerColor = Surface) {
                val labels = listOf("Beranda","Qur'an","Fitur")
                val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Explore)
                labels.forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = label) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            if (vm.selected != null) {
                ReaderScreen(vm.selected!!) { vm.selected = null }
            } else {
                when(tab) {
                    0 -> HomeScreen { tab = 1 }
                    1 -> QuranScreen(vm)
                    else -> FeaturesScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onRead:() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("السَّلَامُ عَلَيْكُمْ", color = Gold, fontSize = 18.sp)
            Text("Al-Qur'an Digital", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Emerald),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text(
                        "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
                        color = Color.White,
                        fontSize = 27.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    Text(
                        "Baca, dengarkan, dan dekatkan hati dengan Al-Qur'an.",
                        color = Color.White.copy(alpha = .9f)
                    )
                    Spacer(Modifier.height(18.dp))
                    Button(
                        onClick = onRead,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Gold,
                            contentColor = Deep
                        )
                    ) {
                        Icon(Icons.Default.MenuBook, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Mulai Membaca")
                    }
                }
            }
        }
        item {
            Text("Fitur Utama", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FeatureCard("🕌","Salat")
                FeatureCard("🧭","Kiblat")
                FeatureCard("📿","Tasbih")
                FeatureCard("🤲","Doa")
            }
        }
    }
}

@Composable
fun FeatureCard(icon:String, label:String) {
    Card(
        Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = Surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(icon, fontSize = 23.sp)
            Text(label, color = Color.White, fontSize = 11.sp)
        }
    }
}

@Composable
fun QuranScreen(vm:QuranViewModel) {
    var search by remember { mutableStateOf("") }
    val filtered = vm.surahs.filter {
        it.englishName.contains(search, true) ||
        it.name.contains(search, true) ||
        it.number.toString() == search
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Al-Qur'an", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Cari surah...") },
            leadingIcon = { Icon(Icons.Default.Search, null) }
        )
        Spacer(Modifier.height(10.dp))

        if (vm.loading && vm.surahs.isEmpty()) {
            CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        }

        vm.error?.let {
            Text(it, color = Color(0xFFFFB4AB), modifier = Modifier.padding(8.dp))
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { s ->
                Card(
                    Modifier.fillMaxWidth().clickable { vm.openSurah(s.number) },
                    colors = CardDefaults.cardColors(containerColor = Surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        Modifier.padding(15.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(shape = RoundedCornerShape(12.dp), color = Emerald) {
                            Text("${s.number}", Modifier.padding(10.dp), color = Color.White)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.englishName, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("${s.numberOfAyahs} ayat", color = Color.LightGray, fontSize = 12.sp)
                        }
                        Text(s.name, color = Gold, fontSize = 21.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ReaderScreen(s:SurahDetail, onBack:() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Column {
                Text(s.englishName, color = Color.White, fontWeight = FontWeight.Bold)
                Text("${s.numberOfAyahs} ayat", color = Color.Gray, fontSize = 12.sp)
            }
        }

        LazyColumn(
            Modifier.padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(
                    s.name,
                    color = Gold,
                    fontSize = 30.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                )
            }

            items(s.ayahs) { a ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Surface),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text(
                            a.text,
                            color = Color.White,
                            fontSize = 25.sp,
                            lineHeight = 43.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${a.numberInSurah}", color = Gold, fontSize = 12.sp)
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = {}) {
                                Icon(Icons.Default.BookmarkBorder, null)
                            }
                            IconButton(onClick = {}) {
                                Icon(Icons.Default.Share, null)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FeaturesScreen() {
    var page by remember { mutableStateOf("menu") }

    when(page) {
        "menu" -> FeatureMenu { page = it }
        "prayer" -> PrayerScreen { page = "menu" }
        "qibla" -> QiblaScreen { page = "menu" }
        "tasbih" -> TasbihScreen { page = "menu" }
        "doa" -> DoaScreen { page = "menu" }
        "calendar" -> HijriScreen { page = "menu" }
    }
}

@Composable
fun FeatureMenu(onOpen:(String)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Fitur Muslim", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
        listOf(
            "🕌" to ("Jadwal Salat" to "prayer"),
            "🧭" to ("Arah Kiblat" to "qibla"),
            "📿" to ("Tasbih Digital" to "tasbih"),
            "🤲" to ("Doa Harian" to "doa"),
            "📅" to ("Kalender Hijriah" to "calendar")
        ).forEach { (icon, pair) ->
            item {
                Card(
                    Modifier.fillMaxWidth().clickable { onOpen(pair.second) },
                    colors = CardDefaults.cardColors(containerColor = Surface),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(icon, fontSize = 25.sp)
                        Spacer(Modifier.width(14.dp))
                        Text(pair.first, color = Color.White, fontSize = 17.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun PrayerScreen(onBack:()->Unit) {
    val times = listOf(
        "Imsak" to "04:35",
        "Subuh" to "04:45",
        "Terbit" to "05:58",
        "Zuhur" to "12:00",
        "Asar" to "15:15",
        "Maghrib" to "18:00",
        "Isya" to "19:10"
    )
    SimplePage("🕌 Jadwal Salat", onBack) {
        Text("Waktu contoh — sesuaikan lokasi untuk jadwal akurat.", color = Color.Gray)
        times.forEach { (name, time) ->
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(name, color = Color.White, modifier = Modifier.weight(1f))
                    Text(time, color = Gold, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun QiblaScreen(onBack:()->Unit) {
    val context = LocalContext.current
    var azimuth by remember { mutableFloatStateOf(0f) }
    DisposableEffect(Unit) {
        val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val listener = object: SensorEventListener {
            override fun onSensorChanged(e:SensorEvent) {
                if(e.sensor.type == Sensor.TYPE_ORIENTATION) azimuth = e.values[0]
            }
            override fun onAccuracyChanged(s:Sensor?, accuracy:Int) {}
        }
        val sensor = manager.getDefaultSensor(Sensor.TYPE_ORIENTATION)
        if(sensor != null) manager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { manager.unregisterListener(listener) }
    }
    SimplePage("🧭 Arah Kiblat", onBack) {
        Text("Kompas perangkat: ${azimuth.toInt()}°", color = Gold, fontSize = 22.sp)
        Text("Arah kiblat dihitung berdasarkan lokasi pengguna pada versi lanjutan.", color = Color.Gray)
    }
}

@Composable
fun TasbihScreen(onBack:()->Unit) {
    var count by remember { mutableIntStateOf(0) }
    var target by remember { mutableIntStateOf(33) }
    SimplePage("📿 Tasbih Digital", onBack) {
        Text("$count / $target", color = Gold, fontSize = 56.sp, fontWeight = FontWeight.Bold)
        Button(
            onClick = { count = if(count >= target) 0 else count + 1 },
            colors = ButtonDefaults.buttonColors(containerColor = Emerald)
        ) { Text("TASBIH") }
        OutlinedButton(onClick = { count = 0 }) { Text("Reset") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(33, 99, 100).forEach { n ->
                FilterChip(selected = target == n, onClick = { target = n; count = 0 }, label = { Text("$n") })
            }
        }
    }
}

@Composable
fun DoaScreen(onBack:()->Unit) {
    val doa = listOf(
        "Doa sebelum makan" to "بِسْمِ اللَّهِ",
        "Doa setelah makan" to "الْحَمْدُ لِلَّهِ",
        "Doa masuk rumah" to "اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلَجِ"
    )
    SimplePage("🤲 Doa Harian", onBack) {
        doa.forEach { (title, arab) ->
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text(title, color = Gold, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(arab, color = Color.White, fontSize = 24.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
fun HijriScreen(onBack:()->Unit) {
    val date = SimpleDateFormat("dd MMMM yyyy", Locale("id","ID")).format(Date())
    SimplePage("📅 Kalender Hijriah", onBack) {
        Text("Tanggal Masehi", color = Color.Gray)
        Text(date, color = Color.White, fontSize = 23.sp)
        Text("Kalender Hijriah lengkap dapat disinkronkan dengan lokasi dan tanggal perangkat.", color = Color.Gray)
    }
}

@Composable
fun SimplePage(title:String, onBack:()->Unit, content:@Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}
