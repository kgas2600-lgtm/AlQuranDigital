# Al-Qur'an Digital

Project Android Kotlin + Jetpack Compose.

Fitur:
- Al-Qur'an dan pembaca surah
- Jadwal salat
- Arah kiblat
- Tasbih digital
- Doa harian
- Kalender Hijriah

Catatan: workflow GitHub Actions dibuat terpisah dan tidak disertakan di ZIP ini.
