# Al-Qur'an Digital v5.0

Perbaikan utama:
- Jadwal salat menggunakan halaman resmi Muslim Pro untuk Jakarta.
- Bismillah ditampilkan sebagai bagian terpisah dari ayat pertama; teks ayat pertama tidak lagi menggabungkan Bismillah.
- Doa harian diperbaiki dan dilengkapi dengan teks Arab berharakat serta terjemahan Indonesia.
- ZIP ini sengaja tanpa GitHub Actions workflow.

Sumber jadwal salat: https://app.muslimpro.com/id/prayer-times/indonesia/jakarta-prayer-times/1642911


## FIXED6
- UI premium/modern dengan tipografi Arab lebih rapi.
- Bismillah Al-Qur'an dipisahkan dari ayat pertama.
- Doa harian diperbaiki dan ditata ulang.
- Arah kiblat dibuat lebih mudah digunakan dengan lokasi + sensor kompas.
- Jadwal salat tetap menggunakan halaman Muslim Pro.


## Sumber Al-Qur'an
Teks Al-Qur'an Utsmani pada pembaca diambil dari Tanzil.net:
https://tanzil.net/pub/quran-uthmani.txt

## Doa Harian
Kumpulan doa harian menggunakan rujukan umum yang diselaraskan dengan referensi NU Online. 
