package com.example.alqurandigital

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.BackHandler
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

private val Deep = Color(0xFF06150F)
private val Surface = Color(0xFF10271F)
private val Emerald = Color(0xFF0B6B4F)
private val Gold = Color(0xFFD8B15A)
private val Cream = Color(0xFFF7F0D8)
private val Muted = Color(0xFFA8B9B2)

private fun getJson(url:String): JSONObject = JSONObject(URL(url).openStream().bufferedReader().use{it.readText()})

private data class Surah(val number:Int,val name:String,val english:String,val ayahs:Int)
private data class Ayah(val number:Int,val text:String,val numberInSurah:Int)
private data class Prayer(val name:String,val time:String)

private class QuranRepository {
    suspend fun surahs(): List<Surah> = withContext(Dispatchers.IO) {
        val d=getJson("https://api.alquran.cloud/v1/surah").getJSONArray("data")
        (0 until d.length()).map { o-> val x=d.getJSONObject(o); Surah(x.getInt("number"),x.getString("name"),x.getString("englishName"),x.getInt("numberOfAyahs")) }
    }
    suspend fun ayahs(n:Int): Pair<Surah,List<Ayah>> = withContext(Dispatchers.IO) {
        val x=getJson("https://api.alquran.cloud/v1/surah/$n/quran-uthmani").getJSONObject("data")
        val s=Surah(x.getInt("number"),x.getString("name"),x.getString("englishName"),x.getInt("numberOfAyahs"))
        val a=x.getJSONArray("ayahs"); val list=(0 until a.length()).map{q->val z=a.getJSONObject(q);Ayah(z.getInt("number"),z.getString("text"),z.getInt("numberInSurah"))}; s to list
    }
    suspend fun prayers(lat:Double,lon:Double):List<Prayer> = withContext(Dispatchers.IO){
        val date=SimpleDateFormat("dd-MM-yyyy",Locale.US).format(Date())
        val x=getJson("https://api.aladhan.com/v1/timings/$date?latitude=$lat&longitude=$lon&method=20").getJSONObject("data")
        val t=x.getJSONObject("timings")
        listOf(Prayer("Subuh",t.getString("Fajr")),Prayer("Terbit",t.getString("Sunrise")),Prayer("Dzuhur",t.getString("Dhuhr")),Prayer("Ashar",t.getString("Asr")),Prayer("Maghrib",t.getString("Maghrib")),Prayer("Isya",t.getString("Isha")))
    }
}

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{Theme{App()}}}
}

@Composable fun Theme(content:@Composable()->Unit)=MaterialTheme(colorScheme=darkColorScheme(primary=Emerald,secondary=Gold,background=Deep,surface=Surface,onSurface=Color.White),content=content)

@Composable fun App(){
    var page by remember{mutableStateOf("home")}; var selected by remember{mutableStateOf<Surah?>(null)}
    if(page in setOf("prayer","qibla","tasbih","doa","hijri")){BackHandler{page="features"}}
    Scaffold(containerColor=Deep,bottomBar={if(page in setOf("home","quran","features"))NavigationBar(containerColor=Color(0xFF0A2118)){listOf("home" to "Beranda", "quran" to "Al-Qur'an", "features" to "Fitur").forEach{(p,l)->NavigationBarItem(selected=page==p,onClick={page=p;selected=null},icon={Icon(if(p=="home")Icons.Default.Home else if(p=="quran")Icons.Default.MenuBook else Icons.Default.Explore,null)},label={Text(l)})}}}){pad->Box(Modifier.padding(pad).fillMaxSize()){
        if(selected!=null)Reader(selected!!){selected=null}else when(page){"home"->Home{page="quran"};"quran"->Quran{selected=it};"features"->Features{page=it};"prayer"->PrayerScreen();"qibla"->QiblaScreen();"tasbih"->TasbihScreen();"doa"->DoaScreen();"hijri"->HijriScreen()}
    }}
}
