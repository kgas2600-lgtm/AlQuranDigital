# Al-Qur'an Digital 2.0

Aplikasi Android berbasis Jetpack Compose dengan:
- Al-Qur'an 114 surah dan ayat Utsmani dari Al Quran Cloud API
- Jadwal salat berdasarkan lokasi perangkat (AlAdhan API)
- Arah kiblat dengan perhitungan bearing Ka'bah dan kompas sensor
- Tasbih digital dengan target dan reset
- Doa harian
- Kalender Hijriah dan tanggal Hijriah saat ini
- Bookmark lokal untuk ayat

Build: Java 17 + Android Gradle Plugin 8.7.3 + Gradle 8.9.
