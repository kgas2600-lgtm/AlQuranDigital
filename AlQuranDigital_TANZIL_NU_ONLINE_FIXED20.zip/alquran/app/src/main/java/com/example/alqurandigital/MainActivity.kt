package com.example.alqurandigital

import android.os.Looper
import android.os.Handler
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.DisposableEffect
import android.media.MediaPlayer
import android.media.AudioAttributes


import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt


data class Qari(
    val id: String,
    val name: String,
    val edition: String
)

private data class DailyDua(
    val title: String,
    val arabic: String,
    val latin: String,
    val meaning: String
)

private val COMPLETE_DAILY_DUAS = listOf(
    DailyDua("Doa Masuk Rumah", "اَللّٰهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلَجِ وَخَيْرَ الْمَخْرَجِ بِاسْمِ اللهِ وَلَجْنَا، وَبِاسْمِ اللهِ خَرَجْنَا، وَعَلَى اللهِ رَبِّنَا تَوَكَّلْنَا", "Allâhumma innî as’aluka khairal maulaji wa khairal makhraji, bismillâhi walajnâ wa bismillâhi kharajnâ wa ‘ala-Llâhi rabbinâ tawakkalnâ", "Ya Allah, aku memohon kepada-Mu sebaik-baik tempat masuk dan tempat keluar. Atas nama-Mu kami masuk dan atas nama-Mu kami keluar. Dan kepada Allah Tuhan kami, kami bertawakal."),
    DailyDua("Doa Keluar Rumah", "بِسْمِ اللهِ تَوَكَّلْتُ عَلَى اللهِ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللهِ", "Bismillâhi tawakkaltu ‘alallâhi wa lâ ḫaula wa lâ quwwata illâ billâh(i)", "Dengan nama Allah, aku bertawakal kepada Allah. Tidak ada daya dan kekuatan kecuali dengan pertolongan Allah."),
    DailyDua("Doa Sebelum Tidur", "اَللّٰهُمَّ بِسْمِكَ أَحْيَا وَبِسْمِكَ أَمُوْتُ", "Allâhumma bismika aḫyâ wa bismika amût(u)", "Ya Allah, dengan nama-Mu aku hidup dan dengan nama-Mu pula aku mati."),
    DailyDua("Doa Bangun Tidur", "اَلْحَمْدُ لِلّٰهِ الَّذِيْ أَحْيَانَا بَعْدَمَا أَمَاتَنَا وَإِلَيْهِ النُّشُوْرُ", "Alḫamdulillâhil ladzî aḫyânâ ba‘da mâ amâtanâ wa ilaihin nusyûr(u)", "Segala puji bagi Allah yang menghidupkanku kembali setelah mematikanku dan hanya kepada-Nya akan bangkit."),
    DailyDua("Doa Masuk Kamar Mandi", "بِسْمِ اللهِ اَللّٰهُمَّ إِنِّيْ أَعُوْذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ", "Bismillâhi allâhumma innî a‘ûdzu bika minal khubutsi wal khabâits(i)", "Dengan nama Allah, ya Allah, aku berlindung kepada-Mu dari godaan setan laki-laki dan setan perempuan."),
    DailyDua("Doa Keluar Kamar Mandi", "غُفْرَانَكَ الْحَمْدُ لِلّٰهِ الَّذِيْ أَذْهَبَ عَنِّيْ الْأَذَى وَعَافَانِيْ", "Ghufrânaka alḫamdulillâhil-ladzî adzhaba ‘annil adzâ wa ‘âfânî", "Dengan mengharap ampunan-Mu, segala puji bagi Allah yang telah menghilangkan penyakit dari tubuhku dan menyehatkanku."),
    DailyDua("Doa Sebelum Makan", "اَللّٰهُمَّ بَارِكْ لَنَا فِيْمَا رَزَقْتَنَا وَقِنَا عَذَابَ النَّارِ", "Allâhumma bârik lanâ fîmâ razaqtanâ waqinâ ‘adzâban nâr(i)", "Ya Allah, berkahilah apa yang telah Engkau anugerahkan kepada kami dan jagalah kami dari siksa neraka."),
    DailyDua("Doa Sesudah Makan", "اَلْحَمْدُ لِلّٰهِ الَّذِيْ أَطْعَمَنَا وَسَقَــــانَا وَجَعَلَنَا مِنَ الْمُسْلِمِيْنَ", "Alḫamdulillâhilladzî ath‘amanâ wa saqânâ wa ja‘alanâ minal muslimîn(a)", "Segala puji bagi Allah yang telah memberi kami makan dan minum, serta menjadikan kami sebagai orang-orang yang berserah diri."),
    DailyDua("Doa Masuk Masjid", "اَللّٰهُمَّ اغْفِرْ لِيْ ذُنُوْبِيْ وَافْتَحْ لِيْ أَبْوَابَ رَحْمَتِكَ", "Allâhummaghfir lî dzunûbî waftaḫ lî abwâba raḫmatik(a)", "Ya Allah, ampuni segala dosaku dan bukalah bagiku segala pintu rahmat-Mu."),
    DailyDua("Doa Keluar Masjid", "اَللّٰهُمَّ اغْفِرْ لِيْ ذُنُوْبِيْ وَافْتَحْ لِيْ أَبْوَابَ فَضْلِكَ", "Allâhummaghfirlî dzunûbî waftaḫ lî abwâba fadl-lik(a)", "Ya Allah, ampuni segala dosaku. Bukakanlah bagiku segala pintu anugerah-Mu."),
    DailyDua("Doa Sesudah Adzan", "اَللّٰهُمَّ رَبَّ هٰذِهِ الدَّعْوَةِ التَّامَّةِ وَالصَّلَاةِ الْقَائِمَةِ اٰتِ سَيِّدَنَـا مُحَمَّدًا الْوَسِيْلَةَ وَالْفَضِيْلَةَ وَالدَّرَجَةَ الرَّفِيْعَةَ وَابْعَثْهُ مَقَامًا مَحْمُوْدًا الَّذِيْ وَعَدْتَهُ إِنَّكَ لَا تُخْلِفُ الْمِيعَادَ", "Allâhumma Rabba hâdzihid-da‘watit-tâmmati, wash-shalâtil-qâimati, âti sayyidanâ Muḫammada nil-wasîlata wal fadlîlata wad darajatar rafî‘ah, wab‘ats-hu maqâman maḫmûdani-lladzî wa‘adtah, innaka lâ tukhliful-mî‘âd(a)", "Ya Allah Tuhan yang memiliki seruan yang sempurna dan shalat yang tetap didirikan, karuniailah Nabi Muhammad wasilah, keutamaan, dan derajat yang tinggi. Tempatkanlah beliau pada kedudukan yang terpuji yang telah Kaujanjikan. Sungguh Engkau tiada menyalahi janji."),
    DailyDua("Doa Bercermin", "اَللّٰهُمَّ كَمَا حَسَّنْتَ خَلْقِيْ فَحَسِّنْ خُلُقِيْ", "Allâhumma kamâ ḫassanta khalqî faḫassin khuluqî", "Hai Tuhanku, sebagaimana telah Kaubaguskan kejadianku, maka baguskanlah perangai ku."),
    DailyDua("Doa Mengenakan Pakaian Baru", "اَللّٰهُمَّ لَكَ الْحَمْدُ أَنْتَ كَسَوْتَنِيْهِ أَسْأَلُكَ خَيْرَهُ وَخَيْرَ مَا صُنِعَ لَهُ وَأَعُوْذُ بِكَ مِنْ شَرِّهِ وَشَرِّ مَا صُنِعَ لَهُ", "Allâhumma lakal ḫamdu anta kasautanîhi, as-aluka khairahu wa khaira mâ shuni‘a lahû wa a‘ûdzu bika min syarrihi wa syarri mâ shuni‘a lahû", "Ya Allah bagi-Mu segala puji. Engkau telah memakaikannya untukku, aku memohon kepada-Mu kebaikannya dan kebaikan apa yang ia dijadikan untuknya, dan aku berlindung dari keburukannya dan keburukan apa yang ia dijadikan untuknya."),
    DailyDua("Doa Memakai Pakaian", "اَللّٰهُمَّ إِنِّي أَسْأَلُكَ مِنْ خَيْرِهِ وَخَيْرِ مَا هُوَ لَهُ، وَأَعُوْذُ بِكَ مِنْ شَرِّهِ وَشَرِّ مَا هُوَ لَهُ", "Allâhumma innî as’aluka min khairihi wa khairi mâ huwa lahu, wa a‘ûdzubika min syarrihi wa syarri mâ huwa lahu", "Ya Allah, sungguh aku memohon kepada-Mu kebaikan pakaian ini dan kebaikan sesuatu yang di dalamnya, dan aku berlindung dari keburukan pakaian ini dan keburukan sesuatu yang ada di dalamnya."),
    DailyDua("Doa Melepas Pakaian", "بِسْمِ اللهِ الَّذِيْ لَا إِلٰهَ إِلَّا هُوَ", "Bismillâhil ladzî lâilâha illâ huwa", "Dengan nama Allah yang tiada tuhan selain Dia."),
    DailyDua("Doa Saat Turun Hujan", "اَللّٰهُمَّ صَيِّبًا نَافِعًا", "Allâhummâ shayyiban nâfi'an", "Ya Allah, turunkanlah pada kami hujan yang bermanfaat."),
    DailyDua("Doa Setelah Hujan Reda", "مُطِرْنَا بِفَضْلِ اللهِ وَرَحْمَتِهِ", "Muthirnâ bi fadhlillâhi wa raḫmatih", "Semoga kita dihujani dengan anugerah dan rahmat Allah."),
    DailyDua("Doa untuk Kedua Orang Tua", "رَبِّ اغْفِرْ لِيْ وَلِوَالِدَيَّ وَارْحَمْهُمَا كَمَا رَبَّيَانِيْ صَغِيْرًا", "Rabbighfir lî wa li wâlidayya warḫamhumâ kamâ rabbayânî shaghîrâ", "Tuhanku, ampunilah diriku dan kedua orang tuaku, sayangilah mereka sebagaimana mereka menyayangiku di waktu aku kecil."),
    DailyDua("Doa Masuk Pasar atau Mal", "بِاسْمِ اللّٰهِ، اَللّٰهُمَّ إِنِّيْ أَسْأَلُكَ خَيْرَ هٰذِهِ السُّوْقِ وَخَيْرَ مَا فِيْهَا وَأَعُوْذُ بِكَ مِنْ شَرِّهَا وَشَرِّ مَا فِيْهَا، اَللّٰهُمَّ إِنِّيْ أَعُوْذُ بِكَ أَنْ أُصِيْبَ فِيْهَا يَمِيْنًا فَاجِرَةً أَوْ صَفْقَةً خَاسِرَةً", "Bismillâh allâhumma innî as-aluka khaira hâdzihi-s-sûqi wa khaira mâ fîhâ wa a‘ûdzubika min syarrihâ wa syarri mâ fîhâ. Allâhumma innî a‘ûdzubika an ushîba fîhâ yamînan fâjiratan au shafqatan khâsiratan", "Dengan nama Allah, ya Allah, aku memohon kebaikan dari pasar ini dan kebaikan dari apa yang ada di dalamnya. Aku berlindung dari keburukan pasar ini dan keburukan apa yang ada di dalamnya. Ya Allah, aku berlindung dari sumpah palsu dan transaksi yang merugikan." )
)

private val QARI_LIST = listOf(
    Qari("alafasy", "Mishary Rashid Alafasy", "ar.alafasy"),
    Qari("husary", "Mahmoud Khalil Al-Husary", "ar.husary"),
    Qari("minshawi", "Muhammad Siddiq Al-Minshawi", "ar.minshawi"),
    Qari("abdulbasit", "Abdul Basit Abdus-Samad", "ar.abdulbasitmurattal"),
    Qari("shuraym", "Saud Al-Shuraim", "ar.saoodshuraym")
)

private class MurattalPlayer {
    private var player: MediaPlayer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var token = 0

    fun play(
        globalAyahNumber: Int,
        qari: Qari,
        onStarted: () -> Unit = {},
        onFinished: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        stop()
        val myToken = ++token

        Thread {
            try {
                val apiUrl =
                    "https://api.alquran.cloud/v1/ayah/$globalAyahNumber/${qari.edition}"
                val connection = (java.net.URL(apiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("Accept", "*/*")
                }

                val json = try {
                    if (connection.responseCode !in 200..299) {
                        throw IllegalStateException("HTTP ${connection.responseCode}")
                    }
                    connection.inputStream.bufferedReader().use { it.readText() }
                } finally {
                    connection.disconnect()
                }

                val audioUrl = JSONObject(json)
                    .getJSONObject("data")
                    .getString("audio")

                if (myToken != token) return@Thread

                mainHandler.post {
                    if (myToken != token) return@post
                    try {
                        player = MediaPlayer().apply {
                            setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .build()
                            )
                            setDataSource(audioUrl)
                            setOnPreparedListener {
                                if (myToken == token) {
                                    it.start()
                                    onStarted()
                                } else {
                                    it.release()
                                }
                            }
                            setOnCompletionListener {
                                onFinished()
                                it.release()
                                if (player === it) player = null
                            }
                            setOnErrorListener { mp, _, _ ->
                                mp.release()
                                if (player === mp) player = null
                                onError("Audio qori tidak dapat diputar.")
                                true
                            }
                            prepareAsync()
                        }
                    } catch (e: Exception) {
                        onError("Audio qori gagal dimuat.")
                    }
                }
            } catch (e: Exception) {
                if (myToken == token) {
                    mainHandler.post {
                        if (myToken == token) {
                            onError("Koneksi audio gagal. Periksa internet lalu coba lagi.")
                        }
                    }
                }
            }
        }.start()
    }

    fun playSurah(
        globalAyahNumbers: List<Int>,
        qari: Qari,
        onAyahStarted: (Int) -> Unit = {},
        onFinished: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        stop()
        if (globalAyahNumbers.isEmpty()) {
            onFinished()
            return
        }
        var current = 0
        fun next() {
            if (current >= globalAyahNumbers.size) {
                onFinished()
                return
            }
            val ayahNo = globalAyahNumbers[current]
            onAyahStarted(current)
            play(
                globalAyahNumber = ayahNo,
                qari = qari,
                onStarted = {},
                onFinished = { current++; next() },
                onError = onError
            )
        }
        next()
    }

    fun stop() {
        token++
        mainHandler.post {
            player?.let {
                try {
                    if (it.isPlaying) it.stop()
                } catch (_: Exception) {}
                try { it.release() } catch (_: Exception) {}
            }
            player = null
        }
    }
}

private val QuranFontFamily = FontFamily(Font(R.font.amiri_quran))
private val ArabicDuaFontFamily = FontFamily(Font(R.font.amiri_regular))

private val QuranArabicStyle = androidx.compose.ui.text.TextStyle(
    fontFamily = QuranFontFamily,
    textDirection = TextDirection.Rtl,
    platformStyle = PlatformTextStyle(includeFontPadding = true),
    lineHeight = 68.sp,
    lineHeightStyle = LineHeightStyle(
        alignment = LineHeightStyle.Alignment.Center,
        trim = LineHeightStyle.Trim.None
    ),
    letterSpacing = 0.sp
)

private val DuaArabicStyle = androidx.compose.ui.text.TextStyle(
    fontFamily = ArabicDuaFontFamily,
    textDirection = TextDirection.Rtl,
    platformStyle = PlatformTextStyle(includeFontPadding = true),
    lineHeight = 60.sp,
    lineHeightStyle = LineHeightStyle(
        alignment = LineHeightStyle.Alignment.Center,
        trim = LineHeightStyle.Trim.None
    ),
    letterSpacing = 0.sp
)


private val Emerald = Color(0xFF0B6B4F)
private val Deep = Color(0xFF06140F)
private val Surface = Color(0xFF10261E)
private val Surface2 = Color(0xFF17352A)
private val Gold = Color(0xFFD8B15A)
private val White = Color(0xFFF8FBF8)

class QuranViewModel : ViewModel() {
    var surahs by mutableStateOf<List<Surah>>(emptyList())
    var selected by mutableStateOf<SurahDetail?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    private var tanzilCache: Map<Pair<Int, Int>, String>? = null

    init { loadSurahs() }

    fun loadSurahs() = viewModelScope.launch {
        loading = true
        error = null
        try {
            val root = JSONObject(fetchText("https://api.alquran.cloud/v1/surah"))
            val arr = root.getJSONArray("data")
            surahs = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Surah(o.getInt("number"), o.getString("name"), o.getString("englishName"), o.getInt("numberOfAyahs"))
            }
        } catch (_: Exception) {
            error = "Daftar surah belum dapat dimuat. Cek internet."
        }
        loading = false
    }

    fun openSurah(number: Int) = viewModelScope.launch {
        loading = true
        error = null
        try {
            val meta = surahs.firstOrNull { it.number == number }
                ?: throw IllegalStateException("Surah tidak ditemukan")

            // quran-uthmani adalah edisi Utsmani yang berasal dari jalur teks Tanzil.
            // Mengambil per-surah membuat pembaca tidak bergantung pada parser file besar.
            val root = JSONObject(fetchText("https://api.alquran.cloud/v1/surah/$number/quran-uthmani"))
            val data = root.getJSONObject("data")
            val arr = data.getJSONArray("ayahs")
            val ayahs = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Ayah(o.getInt("number"), o.getString("text"), o.getInt("numberInSurah"))
            }
            selected = SurahDetail(meta.number, meta.name, meta.englishName, meta.numberOfAyahs, ayahs)
        } catch (_: Exception) {
            error = "Surah belum dapat dibuka. Periksa internet lalu coba lagi."
        }
        loading = false
    }
}

data class Surah(val number: Int, val name: String, val englishName: String, val numberOfAyahs: Int)
data class Ayah(val number: Int, val text: String, val numberInSurah: Int)
data class SurahDetail(val number: Int, val name: String, val englishName: String, val numberOfAyahs: Int, val ayahs: List<Ayah>)

suspend fun fetchText(urlString: String): String = withContext(Dispatchers.IO) {
    val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 15000
        readTimeout = 20000
        setRequestProperty("Accept", "*/*")
    }
    try {
        if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
        connection.inputStream.bufferedReader().use { it.readText() }
    } finally { connection.disconnect() }
}

class PrayerViewModel : ViewModel() {
    var times by mutableStateOf<List<Pair<String,String>>>(emptyList())
    var hijri by mutableStateOf("Memuat...")
    var locationName by mutableStateOf("Lokasi belum dipilih")
    var timezone by mutableStateOf("Zona waktu mengikuti lokasi")
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    fun loadHijri() = viewModelScope.launch {
        try {
            val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
            val root = JSONObject(fetchText("https://api.aladhan.com/v1/gToH?date=$date"))
            val h = root.getJSONObject("data").getJSONObject("hijri")
            hijri = "${h.getString("day")} ${h.getJSONObject("month").getString("en")} ${h.getString("year")} H"
        } catch (_: Exception) { hijri = "Tanggal Hijriah tidak tersedia" }
    }

    fun load(lat: Double, lon: Double) = viewModelScope.launch {
        loading = true; error = null
        try {
            val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
            val root = JSONObject(fetchText("https://api.aladhan.com/v1/timings/$date?latitude=$lat&longitude=$lon&method=20&school=0&midnightMode=0"))
            val d = root.getJSONObject("data")
            timezone = root.getJSONObject("data").getJSONObject("meta").optString("timezone", "Zona waktu mengikuti lokasi")
            val t = d.getJSONObject("timings")
            val keys = listOf("Fajr" to "Subuh", "Sunrise" to "Terbit", "Dhuhr" to "Zuhur", "Asr" to "Asar", "Maghrib" to "Maghrib", "Isha" to "Isya")
            times = keys.map { (api, label) -> label to t.optString(api, "--:--").take(5) }
            val h = d.getJSONObject("date").getJSONObject("hijri")
            hijri = "${h.getString("day")} ${h.getJSONObject("month").getString("en")} ${h.getString("year")} H"
        } catch (_: Exception) { error = "Jadwal gagal dimuat. Pastikan lokasi dan internet aktif." }
        loading = false
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranTheme { QuranApp() } }
    }
}

@Composable
fun QuranTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Emerald, secondary = Gold, background = Deep, surface = Surface, onSurface = White), content = content)
}

@Composable
fun QuranApp(quranVm: QuranViewModel = viewModel(), prayerVm: PrayerViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var feature by remember { mutableStateOf<String?>(null) }
    Scaffold(
        containerColor = Deep,
        bottomBar = {
            NavigationBar(containerColor = Surface) {
                val labels = listOf("Beranda", "Al-Qur'an", "Fitur")
                val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Explore)
                labels.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i && feature == null, onClick = { tab = i; feature = null }, icon = { Icon(icons[i], null) }, label = { Text(label) }) }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when {
                quranVm.selected != null -> ReaderScreen(quranVm.selected!!) { quranVm.selected = null }
                feature != null -> when (feature) {
                    "prayer" -> PrayerScreen(prayerVm) { feature = null }
                    "qibla" -> QiblaScreen { feature = null }
                    "tasbih" -> TasbihScreen { feature = null }
                    "doa" -> DoaScreen { feature = null }
                    "calendar" -> HijriScreen(prayerVm) { feature = null }
                }
                tab == 0 -> HomeScreen { tab = 1 }
                tab == 1 -> QuranScreen(quranVm)
                else -> FeatureMenu { feature = it }
            }
        }
    }
}

@Composable
fun HomeScreen(onRead: () -> Unit) {
    val date = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id","ID")).format(Date())
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("السَّلَامُ عَلَيْكُمْ", color = Gold, style = QuranArabicStyle.copy(fontSize = 20.sp, textAlign = TextAlign.Center), modifier = Modifier.fillMaxWidth()); Text("Al-Qur'an Digital", color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text(date, color = Color.LightGray) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(26.dp)) { Column(Modifier.padding(22.dp)) { Text("بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ", color = White, style = QuranArabicStyle.copy(fontSize = 28.sp, textAlign = TextAlign.Center), modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(14.dp)); Text("Baca Al-Qur'an, cek waktu salat, arah kiblat, doa, tasbih, dan kalender Hijriah.", color = White.copy(.9f)); Spacer(Modifier.height(18.dp)); Button(onClick = onRead, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Deep)) { Icon(Icons.Default.MenuBook, null); Spacer(Modifier.width(8.dp)); Text("Mulai Membaca") } } } }
        item { Text("Fitur Utama", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { FeatureCard(Modifier.weight(1f), "🕌", "Salat"); FeatureCard(Modifier.weight(1f), "🧭", "Kiblat"); FeatureCard(Modifier.weight(1f), "📿", "Tasbih"); FeatureCard(Modifier.weight(1f), "🤲", "Doa") } }
    }
}

@Composable fun FeatureCard(modifier: Modifier, icon: String, label: String) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(icon, fontSize = 23.sp); Text(label, color = White, fontSize = 11.sp) } } }

@Composable
fun QuranScreen(vm: QuranViewModel) {
    var search by remember { mutableStateOf("") }
    val filtered = vm.surahs.filter { it.englishName.contains(search, true) || it.name.contains(search, true) || it.number.toString() == search }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Al-Qur'an", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Cari surah atau nomor...") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        vm.error?.let { Text(it, color = Color(0xFFFFB4AB), modifier = Modifier.padding(8.dp)) }
        if (vm.loading && vm.surahs.isEmpty()) Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        LazyColumn(Modifier.fillMaxSize().padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { s -> Card(Modifier.fillMaxWidth().clickable { vm.openSurah(s.number) }, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Surface(shape = RoundedCornerShape(12.dp), color = Emerald) { Text("${s.number}", Modifier.padding(10.dp), color = White) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(s.englishName, color = White, fontWeight = FontWeight.Bold); Text("${s.numberOfAyahs} ayat", color = Color.LightGray, fontSize = 12.sp) }; Text(s.name, color = Gold, fontSize = 21.sp) } } }
        }
    }
}

private const val BISMILLAH = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"

private fun removeLeadingBismillah(text: String): String {
    val original = text.replace("\uFEFF", "").trim()

    fun normalizeArabic(value: String): String = buildString {
        for (c in value) {
            when {
                c.isWhitespace() || c == '\u0640' -> Unit
                c in '\u0610'..'\u061A' || c in '\u064B'..'\u065F' || c == '\u0670' || c in '\u06D6'..'\u06ED' -> Unit
                c == 'ٱ' || c == 'أ' || c == 'إ' || c == 'آ' -> append('ا')
                c == 'ى' -> append('ي')
                else -> append(c)
            }
        }
    }

    val target = normalizeArabic(BISMILLAH)
    if (!normalizeArabic(original).startsWith(target)) return original

    var normalizedCount = 0
    var index = 0
    while (index < original.length && normalizedCount < target.length) {
        val c = original[index]
        val ignored = c.isWhitespace() || c == '\u0640' ||
            c in '\u0610'..'\u061A' || c in '\u064B'..'\u065F' ||
            c == '\u0670' || c in '\u06D6'..'\u06ED'
        if (!ignored) normalizedCount++
        index++
    }
    return original.substring(index).trimStart()
}

@Composable
fun ReaderScreen(s: SurahDetail, onBack: () -> Unit) {
    var selectedQari by remember { mutableStateOf(QARI_LIST.first()) }

    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("alquran", Context.MODE_PRIVATE) }
    var bookmarks by remember { mutableStateOf(prefs.getStringSet("bookmarks", emptySet()) ?: emptySet()) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Column { Text(s.englishName, color = White, fontWeight = FontWeight.Bold); Text("${s.numberOfAyahs} ayat", color = Color.Gray, fontSize = 12.sp) }
        }
                Text("Teks Utsmani • Sumber: Tanzil Project", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 14.dp))
        
        var qariExpanded by remember { mutableStateOf(false) }
        Text(
            "Qari Murattal",
            color = Gold,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 14.dp)
        )
        Box(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            OutlinedButton(
                onClick = { qariExpanded = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Pilih Qari: ${selectedQari.name}", color = White)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ArrowDropDown, contentDescription = "Pilih qari")
            }
            DropdownMenu(
                expanded = qariExpanded,
                onDismissRequest = { qariExpanded = false }
            ) {
                QARI_LIST.forEach { qari ->
                    DropdownMenuItem(
                        text = { Text(qari.name) },
                        onClick = {
                            selectedQari = qari
                            qariExpanded = false
                        }
                    )
                }
            }
        }
        FullSurahMurattalButton(
            globalAyahNumbers = s.ayahs.map { it.number },
            qari = selectedQari
        )
        Spacer(Modifier.height(8.dp))

LazyColumn(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(s.name, color = Gold, style = QuranArabicStyle.copy(fontSize = 27.sp, lineHeight = 64.sp, textAlign = TextAlign.Center), modifier = Modifier.fillMaxWidth().padding(12.dp)) }
            items(s.ayahs) { a ->
                val key = "${s.number}:${a.numberInSurah}"
                val marked = bookmarks.contains(key)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (a.numberInSurah == 1 && s.number != 9) {
                        Card(colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(18.dp)) {
                            Text(BISMILLAH, color = Gold, style = QuranArabicStyle.copy(fontSize = 27.sp, lineHeight = 66.sp, letterSpacing = 0.sp, textAlign = TextAlign.Center), modifier = Modifier.fillMaxWidth().padding(18.dp))
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            val displayedAyah = if (a.numberInSurah == 1 && s.number != 9) removeLeadingBismillah(a.text) else a.text
                            Text(displayedAyah, color = White, style = QuranArabicStyle.copy(fontSize = 27.sp, lineHeight = 68.sp, letterSpacing = 0.sp, textAlign = TextAlign.Right), modifier = Modifier.fillMaxWidth().padding(horizontal = 2.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${a.numberInSurah}", color = Gold, fontSize = 12.sp)
                                Spacer(Modifier.weight(1f))
                                IconButton(onClick = { val set = bookmarks.toMutableSet(); if (marked) set.remove(key) else set.add(key); bookmarks = set; prefs.edit().putStringSet("bookmarks", set).apply() }) {
                                    Icon(if (marked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = Gold)
                                }
                                IconButton(onClick = { val share = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${displayedAyah}\n\nQS ${s.englishName} ayat ${a.numberInSurah}") }; context.startActivity(Intent.createChooser(share, "Bagikan ayat")) }) {
                                    Icon(Icons.Default.Share, null)
                                }
                            }
                                MurattalButton(a.number, selectedQari)
                        }
                    }
                }
            }
        }
    }
}
@Composable
fun FeatureMenu(onOpen: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Fitur Muslim", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Semua fitur di bawah dapat digunakan langsung.", color = Color.Gray) }
        val list = listOf("🕌" to ("Jadwal Salat" to "prayer"), "🧭" to ("Arah Kiblat" to "qibla"), "📿" to ("Tasbih Digital" to "tasbih"), "🤲" to ("Doa Harian" to "doa"), "📅" to ("Kalender Hijriah" to "calendar"))
        list.forEach { entry ->
            val icon = entry.first
            val itemData = entry.second
            item {
                Card(
                    Modifier.fillMaxWidth().clickable { onOpen(itemData.second) },
                    colors = CardDefaults.cardColors(containerColor = Surface),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(icon, fontSize = 25.sp)
                        Spacer(Modifier.width(14.dp))
                        Text(itemData.first, color = White, fontSize = 17.sp)
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
    }
}

@Composable
fun PrayerScreen(vm: PrayerViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }
    val muslimProUrl = "https://app.muslimpro.com/id/prayer-times/indonesia/jakarta-prayer-times/1642911"

    SimplePage("🕌 Jadwal Salat", onBack) {
        Text("Jadwal Salat dari Muslim Pro", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Sumber waktu salat: situs resmi Muslim Pro. Jadwal mengikuti data lokasi Jakarta.", color = Color.LightGray, fontSize = 13.sp)
        OutlinedButton(onClick = { webView?.reload() }) {
            Icon(Icons.Default.Refresh, null)
            Spacer(Modifier.width(6.dp))
            Text("Perbarui Jadwal")
        }
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { ctx ->
                WebView(ctx).apply {
                    webView = this
                    webViewClient = WebViewClient()
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    loadUrl(muslimProUrl)
                }
            },
            update = { webView = it }
        )
    }
}
@Composable fun PrayerRow(name: String, time: String) { Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(14.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(name, color = White, modifier = Modifier.weight(1f)); Text(time, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp) } } }

@Composable
fun QiblaScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var permission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    var qibla by remember { mutableFloatStateOf(0f) }
    var heading by remember { mutableFloatStateOf(0f) }
    var lat by remember { mutableStateOf<Double?>(null) }
    var lon by remember { mutableStateOf<Double?>(null) }
    var sensorReady by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permission =
            result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    fun updateLocation() {
        if (!permission) return
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            val location =
                lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (location != null) {
                lat = location.latitude
                lon = location.longitude
                qibla = bearingToKaaba(location.latitude, location.longitude)
            }
        } catch (_: SecurityException) {
        }
    }

    LaunchedEffect(permission) {
        if (permission) updateLocation()
    }

    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotation = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val listener = object : SensorEventListener {
            private val rotationMatrix = FloatArray(9)
            private val orientation = FloatArray(3)

            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                SensorManager.getOrientation(rotationMatrix, orientation)
                heading = ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
                sensorReady = true
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        if (rotation != null) {
            sm.registerListener(listener, rotation, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { sm.unregisterListener(listener) }
    }

    val relative = ((qibla - heading + 540f) % 360f) - 180f
    val aligned = kotlin.math.abs(relative) <= 8f

    SimplePage("🧭 Arah Kiblat", onBack) {
        Text(
            "Kiblat jadi mudah",
            color = Gold,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Izinkan lokasi, lalu putar HP sampai panah menunjuk ke arah Ka'bah.",
            color = Color.LightGray,
            fontSize = 14.sp,
            lineHeight = 21.sp
        )

        if (!permission) {
            Button(
                onClick = {
                    launcher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Emerald)
            ) {
                Icon(Icons.Default.LocationOn, null)
                Spacer(Modifier.width(8.dp))
                Text("Izinkan Lokasi")
            }
        } else {
            OutlinedButton(
                onClick = { updateLocation() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("Perbarui Lokasi")
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Surface2),
            shape = RoundedCornerShape(26.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    if (aligned) "✓ Menghadap Kiblat" else "Arahkan ke Kiblat",
                    color = if (aligned) Gold else White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                Box(
                    modifier = Modifier.size(240.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        shape = CircleShape,
                        color = Deep
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                "N",
                                color = Gold,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopCenter).padding(top = 14.dp)
                            )
                            Text(
                                "↑",
                                color = Gold,
                                fontSize = 86.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.rotate(relative)
                            )
                            Text(
                                "🕋",
                                fontSize = 31.sp,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "${kotlin.math.round(relative).toInt()}°",
                    color = White,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "putar HP mengikuti arah panah",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Surface),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Status", color = Gold, fontWeight = FontWeight.Bold)
                Text(
                    if (lat != null) "Lokasi: ${lat!!.format(4)}, ${lon!!.format(4)}"
                    else "Lokasi belum tersedia — tekan Perbarui Lokasi.",
                    color = White
                )
                Text(
                    if (sensorReady) "Sensor kompas: aktif" else "Sensor kompas: belum tersedia",
                    color = if (sensorReady) Color.LightGray else Gold,
                    fontSize = 13.sp
                )
                Text(
                    if (qibla > 0f) "Arah Kiblat: ${qibla.toInt()}° dari utara"
                    else "Arah Kiblat: menunggu lokasi",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            }
        }

        Text(
            "Tips: jauhkan HP dari magnet, casing magnet, atau benda logam saat mengkalibrasi kompas.",
            color = Color.Gray,
            fontSize = 12.sp,
            lineHeight = 18.sp
        )
    }
}

fun bearingToKaaba(lat: Double, lon: Double): Float {
    val kaabaLat = Math.toRadians(21.422487); val kaabaLon = Math.toRadians(39.826206); val p1 = Math.toRadians(lat); val l1 = Math.toRadians(lon); val dl = kaabaLon - l1
    return ((Math.toDegrees(Math.atan2(Math.sin(dl), Math.cos(p1) * Math.tan(kaabaLat) - Math.sin(p1) * Math.cos(dl))) + 360) % 360).toFloat()
}

@Composable
fun TasbihScreen(onBack: () -> Unit) {
    val context = LocalContext.current; val prefs = remember { context.getSharedPreferences("tasbih", Context.MODE_PRIVATE) }
    var count by remember { mutableIntStateOf(prefs.getInt("count", 0)) }; var target by remember { mutableIntStateOf(prefs.getInt("target", 33)) }; var phrase by remember { mutableStateOf(prefs.getString("phrase", "سُبْحَانَ اللَّهِ") ?: "سُبْحَانَ اللَّهِ") }
    fun save() = prefs.edit().putInt("count", count).putInt("target", target).putString("phrase", phrase).apply()
    SimplePage("📿 Tasbih Digital", onBack) {
        Text(phrase, color = Gold, fontSize = 25.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text("$count", color = White, fontSize = 70.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text("Target $target", color = Color.Gray, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Button(onClick = { count = if (count >= target) 0 else count + 1; save() }, modifier = Modifier.fillMaxWidth().height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = Emerald)) { Text("TASBIH", fontSize = 20.sp) }
        OutlinedButton(onClick = { count = 0; save() }, modifier = Modifier.fillMaxWidth()) { Text("Reset") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(33, 99, 100).forEach { n -> FilterChip(selected = target == n, onClick = { target = n; count = 0; save() }, label = { Text("$n") }) } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("سُبْحَانَ اللَّهِ", "الْحَمْدُ لِلَّهِ", "اللَّهُ أَكْبَرُ").forEach { p -> FilterChip(selected = phrase == p, onClick = { phrase = p; save() }, label = { Text(p, fontSize = 11.sp) }) } }
    }
}


@Composable
fun FullSurahMurattalButton(
    globalAyahNumbers: List<Int>,
    qari: Qari
) {
    var playing by remember(qari.id, globalAyahNumbers) { mutableStateOf(false) }
    val mp = remember { MurattalPlayer() }

    DisposableEffect(Unit) {
        onDispose { mp.stop() }
    }

    Button(
        onClick = {
            if (playing) {
                mp.stop()
                playing = false
            } else {
                playing = true
                mp.playSurah(
                    globalAyahNumbers = globalAyahNumbers,
                    qari = qari,
                    onFinished = { playing = false },
                    onError = { playing = false }
                )
            }
        },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Surface2)
    ) {
        Text(
            if (playing) "⏹ Hentikan Murattal" else "▶ Putar 1 Surah Sampai Selesai",
            color = Gold,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun MurattalButton(globalAyahNumber: Int, qari: Qari) {
    var playing by remember(qari.id, globalAyahNumber) { mutableStateOf(false) }
    var loading by remember(qari.id, globalAyahNumber) { mutableStateOf(false) }
    var error by remember(qari.id, globalAyahNumber) { mutableStateOf<String?>(null) }
    val mp = remember { MurattalPlayer() }

    DisposableEffect(Unit) {
        onDispose { mp.stop() }
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            onClick = {
                error = null
                if (playing || loading) {
                    mp.stop()
                    playing = false
                    loading = false
                } else {
                    loading = true
                    mp.play(
                        globalAyahNumber = globalAyahNumber,
                        qari = qari,
                        onStarted = {
                            loading = false
                            playing = true
                        },
                        onFinished = {
                            loading = false
                            playing = false
                        },
                        onError = {
                            loading = false
                            playing = false
                            error = it
                        }
                    )
                }
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Surface2)
        ) {
            Text(
                when {
                    loading -> "Memuat…"
                    playing -> "⏹ Berhenti"
                    else -> "▶ Murattal"
                },
                color = Gold,
                fontWeight = FontWeight.Bold
            )
        }

        if (error != null) {
            Text(error!!, color = Color(0xFFFF9E9E), fontSize = 11.sp)
        }
    }
}


@Composable
fun DoaScreen(onBack: () -> Unit) {
    val doa = COMPLETE_DAILY_DUAS
    Column(Modifier.fillMaxSize().background(Deep)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = White) }
            Text("🤲 Doa Harian", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            "Kumpulan doa keseharian yang umum digunakan.",
            color = Color.LightGray,
            fontSize = 14.sp,
            lineHeight = 21.sp,
            modifier = Modifier.padding(horizontal = 18.dp)
        )
        Text(
            "Sumber: Quran NU Online • 19 bacaan",
            color = Gold,
            fontSize = 12.sp,
            lineHeight = 18.sp,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
        )
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            itemsIndexed(doa) { index, dua ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Surface),
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(modifier = Modifier.size(34.dp), shape = CircleShape, color = Surface2) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("${index + 1}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(dua.title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(
                            dua.arabic,
                            color = White,
                            style = DuaArabicStyle.copy(
                                fontSize = 25.sp,
                                lineHeight = 60.sp,
                                letterSpacing = 0.sp,
                                textAlign = TextAlign.Center
                            ),
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
                        )
                        Spacer(Modifier.height(14.dp))
                        Text(dua.latin, color = Color.LightGray, fontSize = 13.sp, lineHeight = 21.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(dua.meaning, color = Color.LightGray, fontSize = 14.sp, lineHeight = 21.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun HijriScreen(vm: PrayerViewModel, onBack: () -> Unit) {
    val date = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID")).format(Date())
    LaunchedEffect(Unit) { vm.loadHijri() }
    SimplePage("📅 Kalender Hijriah", onBack) {
        Text("Hari ini", color = Color.Gray)
        Text(date, color = White, fontSize = 23.sp)
        Text(vm.hijri, color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Kalender Hijriah", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Konversi tanggal Masehi ke Hijriah diperbarui dari layanan AlAdhan.", color = Color.LightGray)
                Spacer(Modifier.height(8.dp))
                Text("Catatan: awal bulan Hijriah dapat berbeda menurut metode/rukyah setempat.", color = Color.Gray, fontSize = 12.sp)
            }
        }
        OutlinedButton(onClick = { vm.loadHijri() }) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Perbarui Tanggal") }
    }
}

@Composable
fun SimplePage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Deep)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = White)
            }
            Text(
                title,
                color = White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Column(
            Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

fun Double.format(decimals: Int): String = String.format(Locale.US, "%.${decimals}f", this)
