package com.example.alqurandigital

import android.os.Looper
import android.os.Handler
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.DisposableEffect
import android.media.MediaPlayer
import android.media.AudioAttributes


import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import java.text.Normalizer


data class Qari(
    val id: String,
    val name: String,
    val edition: String
)

private data class DailyDua(
    val title: String,
    val arabic: String,
    val latin: String,
    val meaning: String
)

private val COMPLETE_DAILY_DUAS = listOf(
    DailyDua("Doa sebelum makan","بِسْمِ اللَّهِ","Bismillāh","Dengan nama Allah."),
    DailyDua("Doa setelah makan","الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ","Al-ḥamdu lillāhilladzī aṭ‘amanī hādzā wa razaqanīhi min ghairi ḥaulin minnī wa lā quwwah","Segala puji bagi Allah yang telah memberiku makanan ini dan rezeki ini tanpa daya dan kekuatan dariku."),
    DailyDua("Doa sebelum tidur","بِاسْمِكَ اللَّهُمَّ أَحْيَا وَبِاسْمِكَ أَمُوتُ","Bismikallāhumma aḥyā wa bismika amūt","Dengan nama-Mu ya Allah aku hidup dan dengan nama-Mu aku mati."),
    DailyDua("Doa bangun tidur","الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ","Al-ḥamdu lillāhilladzī aḥyānā ba‘da mā amātanā wa ilaihin-nusyūr","Segala puji bagi Allah yang telah menghidupkan kami setelah mematikan kami, dan kepada-Nya kebangkitan."),
    DailyDua("Doa masuk kamar mandi","اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ","Allāhumma innī a‘ūdzu bika minal-khubutsi wal-khabā’its","Ya Allah, aku berlindung kepada-Mu dari setan laki-laki dan perempuan."),
    DailyDua("Doa keluar kamar mandi","غُفْرَانَكَ","Ghufrānak","Aku memohon ampunan-Mu."),
    DailyDua("Doa masuk rumah","اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ الْمَوْلَجِ وَخَيْرَ الْمَخْرَجِ، بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا","Allāhumma innī as’aluka khairal-mawlaji wa khairal-makhraj, bismillāhi walajnā wa bismillāhi kharajnā wa ‘alallāhi rabbinā tawakkalnā","Ya Allah, aku memohon kepada-Mu kebaikan tempat masuk dan tempat keluar. Dengan nama Allah kami masuk, dengan nama Allah kami keluar, dan kepada Allah Tuhan kami bertawakal."),
    DailyDua("Doa keluar rumah","بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ","Bismillāh, tawakkaltu ‘alallāh, lā ḥaula wa lā quwwata illā billāh","Dengan nama Allah, aku bertawakal kepada Allah. Tiada daya dan kekuatan kecuali dengan pertolongan Allah."),
    DailyDua("Doa sebelum belajar","رَبِّ زِدْنِي عِلْمًا","Rabbi zidnī ‘ilmā","Ya Tuhanku, tambahkanlah kepadaku ilmu."),
    DailyDua("Doa memohon kemudahan","رَبِّ اشْرَحْ لِي صَدْرِي ۝ وَيَسِّرْ لِي أَمْرِي ۝ وَاحْلُلْ عُقْدَةً مِنْ لِسَانِي ۝ يَفْقَهُوا قَوْلِي","Rabbisyraḥ lī ṣadrī, wa yassir lī amrī, waḥlul ‘uqdatan min lisānī, yafqahū qaulī","Ya Tuhanku, lapangkanlah dadaku, mudahkanlah urusanku, dan lepaskan kekakuan dari lidahku agar mereka memahami perkataanku."),
    DailyDua("Doa untuk kedua orang tua","رَبِّ اغْفِرْ لِي وَلِوَالِدَيَّ وَارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا","Rabbighfir lī wa liwālidayya warḥamhumā kamā rabbayānī ṣaghīrā","Ya Tuhanku, ampunilah aku dan kedua orang tuaku, dan sayangilah mereka sebagaimana mereka menyayangiku ketika kecil."),
    DailyDua("Doa memohon ampun","رَبَّنَا ظَلَمْنَا أَنْفُسَنَا وَإِنْ لَمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ","Rabbanā ẓalamnā anfusanā wa illam taghfir lanā wa tarḥamnā lanakūnanna minal-khāsirīn","Ya Tuhan kami, kami telah menzalimi diri kami. Jika Engkau tidak mengampuni dan merahmati kami, niscaya kami termasuk orang-orang yang rugi."),
    DailyDua("Doa kebaikan dunia akhirat","رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ","Rabbanā ātinā fid-dunyā ḥasanatan wa fil-ākhirati ḥasanatan wa qinā ‘adzāban-nār","Ya Tuhan kami, berilah kami kebaikan di dunia dan kebaikan di akhirat, serta lindungilah kami dari azab neraka."),
    DailyDua("Doa saat bercermin","اللَّهُمَّ أَنْتَ حَسَّنْتَ خَلْقِي فَحَسِّنْ خُلُقِي","Allāhumma anta ḥassanta khalqī faḥassin khuluqī","Ya Allah, sebagaimana Engkau telah membaguskan kejadianku, maka baguskanlah akhlakku."),
    DailyDua("Doa naik kendaraan","سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ ۝ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ","Subḥānalladzī sakhkhara lanā hādzā wa mā kunnā lahū muqrinīn, wa innā ilā rabbinā lamunqalibūn","Mahasuci Allah yang telah menundukkan kendaraan ini bagi kami, padahal kami tidak mampu menguasainya; dan sungguh kepada Tuhan kami akan kembali."),
    DailyDua("Doa masuk masjid","اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ","Allāhummaftaḥ lī abwāba raḥmatik","Ya Allah, bukakanlah untukku pintu-pintu rahmat-Mu."),
    DailyDua("Doa keluar masjid","اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ","Allāhumma innī as’aluka min faḍlik","Ya Allah, aku memohon kepada-Mu karunia-Mu."),
    DailyDua("Doa setelah wudu","أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ","Asyhadu allā ilāha illallāhu waḥdahū lā syarīka lah, wa asyhadu anna Muḥammadan ‘abduhū wa rasūluh","Aku bersaksi bahwa tidak ada Tuhan selain Allah, satu-satunya, tiada sekutu bagi-Nya; dan aku bersaksi bahwa Muhammad adalah hamba dan utusan-Nya."),
    DailyDua("Doa ketika hujan","اللَّهُمَّ صَيِّبًا نَافِعًا","Allāhumma ṣayyiban nāfi‘ā","Ya Allah, turunkanlah hujan yang bermanfaat."),
    DailyDua("Doa berbuka puasa","ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الْأَجْرُ إِنْ شَاءَ اللَّهُ","Dzahabazh-zhama’u wabtallatil-‘urūqu wa tsabatal-ajru insyā’allāh","Telah hilang rasa haus, urat-urat telah basah, dan pahala telah tetap, insya Allah.")
)

private val QARI_LIST = listOf(
    Qari("alafasy", "Mishary Rashid Alafasy", "ar.alafasy"),
    Qari("husary", "Mahmoud Khalil Al-Husary", "ar.husary"),
    Qari("minshawi", "Muhammad Siddiq Al-Minshawi", "ar.minshawi"),
    Qari("abdulbasit", "Abdul Basit Abdus-Samad", "ar.abdulbasitmurattal"),
    Qari("shuraym", "Saud Al-Shuraim", "ar.saoodshuraym")
)

private class MurattalPlayer {
    private var player: MediaPlayer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var token = 0

    fun play(
        globalAyahNumber: Int,
        qari: Qari,
        onStarted: () -> Unit = {},
        onFinished: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        stop()
        val myToken = ++token

        Thread {
            try {
                val apiUrl =
                    "https://api.alquran.cloud/v1/ayah/$globalAyahNumber/${qari.edition}"
                val connection = (java.net.URL(apiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15000
                    readTimeout = 20000
                    setRequestProperty("Accept", "application/json")
                }

                val json = try {
                    if (connection.responseCode !in 200..299) {
                        throw IllegalStateException("HTTP ${connection.responseCode}")
                    }
                    connection.inputStream.bufferedReader().use { it.readText() }
                } finally {
                    connection.disconnect()
                }

                val audioUrl = JSONObject(json)
                    .getJSONObject("data")
                    .getString("audio")

                if (myToken != token) return@Thread

                mainHandler.post {
                    if (myToken != token) return@post
                    try {
                        player = MediaPlayer().apply {
                            setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .build()
                            )
                            setDataSource(audioUrl)
                            setOnPreparedListener {
                                if (myToken == token) {
                                    it.start()
                                    onStarted()
                                } else {
                                    it.release()
                                }
                            }
                            setOnCompletionListener {
                                onFinished()
                                it.release()
                                if (player === it) player = null
                            }
                            setOnErrorListener { mp, _, _ ->
                                mp.release()
                                if (player === mp) player = null
                                onError("Audio qori tidak dapat diputar.")
                                true
                            }
                            prepareAsync()
                        }
                    } catch (e: Exception) {
                        onError("Audio qori gagal dimuat.")
                    }
                }
            } catch (e: Exception) {
                if (myToken == token) {
                    mainHandler.post {
                        if (myToken == token) {
                            onError("Koneksi audio gagal. Periksa internet lalu coba lagi.")
                        }
                    }
                }
            }
        }.start()
    }

    fun playSurah(
        globalAyahNumbers: List<Int>,
        qari: Qari,
        onAyahStarted: (Int) -> Unit = {},
        onFinished: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        stop()
        if (globalAyahNumbers.isEmpty()) {
            onFinished()
            return
        }
        var current = 0
        fun next() {
            if (current >= globalAyahNumbers.size) {
                onFinished()
                return
            }
            val ayahNo = globalAyahNumbers[current]
            onAyahStarted(current)
            play(
                globalAyahNumber = ayahNo,
                qari = qari,
                onStarted = {},
                onFinished = { current++; next() },
                onError = onError
            )
        }
        next()
    }

    fun stop() {
        token++
        mainHandler.post {
            player?.let {
                try {
                    if (it.isPlaying) it.stop()
                } catch (_: Exception) {}
                try { it.release() } catch (_: Exception) {}
            }
            player = null
        }
    }
}

private val QuranFontFamily = FontFamily(Font(R.font.amiri_quran))

private fun tidyArabic(text: String): String {
    return Normalizer.normalize(text, Normalizer.Form.NFC)
        .replace(Regex("[\\u200B-\\u200F\\u202A-\\u202E]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
}


private val Emerald = Color(0xFF0B6B4F)
private val Deep = Color(0xFF06140F)
private val Surface = Color(0xFF10261E)
private val Surface2 = Color(0xFF17352A)
private val Gold = Color(0xFFD8B15A)
private val White = Color(0xFFF8FBF8)

class QuranViewModel : ViewModel() {
    var surahs by mutableStateOf<List<Surah>>(emptyList())
    var selected by mutableStateOf<SurahDetail?>(null)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    init { loadSurahs() }

    fun loadSurahs() = viewModelScope.launch {
        loading = true
        error = null
        try {
            val root = JSONObject(fetchText("https://api.alquran.cloud/v1/surah"))
            val arr = root.getJSONArray("data")
            surahs = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Surah(o.getInt("number"), o.getString("name"), o.getString("englishName"), o.getInt("numberOfAyahs"))
            }
        } catch (_: Exception) { error = "Al-Qur'an belum dapat dimuat. Cek internet." }
        loading = false
    }

    fun openSurah(number: Int) = viewModelScope.launch {
        loading = true
        error = null
        try {
            val root = JSONObject(fetchText("https://api.alquran.cloud/v1/surah/$number/quran-uthmani"))
            val d = root.getJSONObject("data")
            val arr = d.getJSONArray("ayahs")
            val ayahs = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Ayah(o.getInt("number"), o.getString("text"), o.getInt("numberInSurah"))
            }
            selected = SurahDetail(d.getInt("number"), d.getString("name"), d.getString("englishName"), d.getInt("numberOfAyahs"), ayahs)
        } catch (_: Exception) { error = "Surah gagal dimuat. Coba lagi." }
        loading = false
    }
}

data class Surah(val number: Int, val name: String, val englishName: String, val numberOfAyahs: Int)
data class Ayah(val number: Int, val text: String, val numberInSurah: Int)
data class SurahDetail(val number: Int, val name: String, val englishName: String, val numberOfAyahs: Int, val ayahs: List<Ayah>)

suspend fun fetchText(urlString: String): String = withContext(Dispatchers.IO) {
    val connection = (URL(urlString).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 15000
        readTimeout = 20000
        setRequestProperty("Accept", "application/json")
    }
    try {
        if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
        connection.inputStream.bufferedReader().use { it.readText() }
    } finally { connection.disconnect() }
}

class PrayerViewModel : ViewModel() {
    var times by mutableStateOf<List<Pair<String,String>>>(emptyList())
    var hijri by mutableStateOf("Memuat...")
    var locationName by mutableStateOf("Lokasi belum dipilih")
    var timezone by mutableStateOf("Zona waktu mengikuti lokasi")
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    fun loadHijri() = viewModelScope.launch {
        try {
            val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
            val root = JSONObject(fetchText("https://api.aladhan.com/v1/gToH?date=$date"))
            val h = root.getJSONObject("data").getJSONObject("hijri")
            hijri = "${h.getString("day")} ${h.getJSONObject("month").getString("en")} ${h.getString("year")} H"
        } catch (_: Exception) { hijri = "Tanggal Hijriah tidak tersedia" }
    }

    fun load(lat: Double, lon: Double) = viewModelScope.launch {
        loading = true; error = null
        try {
            val date = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())
            val root = JSONObject(fetchText("https://api.aladhan.com/v1/timings/$date?latitude=$lat&longitude=$lon&method=20&school=0&midnightMode=0"))
            val d = root.getJSONObject("data")
            timezone = root.getJSONObject("data").getJSONObject("meta").optString("timezone", "Zona waktu mengikuti lokasi")
            val t = d.getJSONObject("timings")
            val keys = listOf("Fajr" to "Subuh", "Sunrise" to "Terbit", "Dhuhr" to "Zuhur", "Asr" to "Asar", "Maghrib" to "Maghrib", "Isha" to "Isya")
            times = keys.map { (api, label) -> label to t.optString(api, "--:--").take(5) }
            val h = d.getJSONObject("date").getJSONObject("hijri")
            hijri = "${h.getString("day")} ${h.getJSONObject("month").getString("en")} ${h.getString("year")} H"
        } catch (_: Exception) { error = "Jadwal gagal dimuat. Pastikan lokasi dan internet aktif." }
        loading = false
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { QuranTheme { QuranApp() } }
    }
}

@Composable
fun QuranTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(primary = Emerald, secondary = Gold, background = Deep, surface = Surface, onSurface = White), content = content)
}

@Composable
fun QuranApp(quranVm: QuranViewModel = viewModel(), prayerVm: PrayerViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var feature by remember { mutableStateOf<String?>(null) }
    Scaffold(
        containerColor = Deep,
        bottomBar = {
            NavigationBar(containerColor = Surface) {
                val labels = listOf("Beranda", "Al-Qur'an", "Fitur")
                val icons = listOf(Icons.Default.Home, Icons.Default.MenuBook, Icons.Default.Explore)
                labels.forEachIndexed { i, label -> NavigationBarItem(selected = tab == i && feature == null, onClick = { tab = i; feature = null }, icon = { Icon(icons[i], null) }, label = { Text(label) }) }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when {
                quranVm.selected != null -> ReaderScreen(quranVm.selected!!) { quranVm.selected = null }
                feature != null -> when (feature) {
                    "prayer" -> PrayerScreen(prayerVm) { feature = null }
                    "qibla" -> QiblaScreen { feature = null }
                    "tasbih" -> TasbihScreen { feature = null }
                    "doa" -> DoaScreen { feature = null }
                    "calendar" -> HijriScreen(prayerVm) { feature = null }
                }
                tab == 0 -> HomeScreen { tab = 1 }
                tab == 1 -> QuranScreen(quranVm)
                else -> FeatureMenu { feature = it }
            }
        }
    }
}

@Composable
fun HomeScreen(onRead: () -> Unit) {
    val date = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id","ID")).format(Date())
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("السَّلَامُ عَلَيْكُمْ", color = Gold, fontSize = 20.sp, fontFamily = QuranFontFamily, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()); Text("Al-Qur'an Digital", color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold); Text(date, color = Color.LightGray) }
        item { Card(colors = CardDefaults.cardColors(containerColor = Emerald), shape = RoundedCornerShape(26.dp)) { Column(Modifier.padding(22.dp)) { Text("بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ", color = White, fontSize = 28.sp, fontFamily = QuranFontFamily, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(14.dp)); Text("Baca Al-Qur'an, cek waktu salat, arah kiblat, doa, tasbih, dan kalender Hijriah.", color = White.copy(.9f)); Spacer(Modifier.height(18.dp)); Button(onClick = onRead, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Deep)) { Icon(Icons.Default.MenuBook, null); Spacer(Modifier.width(8.dp)); Text("Mulai Membaca") } } } }
        item { Text("Fitur Utama", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { FeatureCard(Modifier.weight(1f), "🕌", "Salat"); FeatureCard(Modifier.weight(1f), "🧭", "Kiblat"); FeatureCard(Modifier.weight(1f), "📿", "Tasbih"); FeatureCard(Modifier.weight(1f), "🤲", "Doa") } }
    }
}

@Composable fun FeatureCard(modifier: Modifier, icon: String, label: String) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(icon, fontSize = 23.sp); Text(label, color = White, fontSize = 11.sp) } } }

@Composable
fun QuranScreen(vm: QuranViewModel) {
    var search by remember { mutableStateOf("") }
    val filtered = vm.surahs.filter { it.englishName.contains(search, true) || it.name.contains(search, true) || it.number.toString() == search }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Al-Qur'an", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Cari surah atau nomor...") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        vm.error?.let { Text(it, color = Color(0xFFFFB4AB), modifier = Modifier.padding(8.dp)) }
        if (vm.loading && vm.surahs.isEmpty()) Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        LazyColumn(Modifier.fillMaxSize().padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered) { s -> Card(Modifier.fillMaxWidth().clickable { vm.openSurah(s.number) }, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Surface(shape = RoundedCornerShape(12.dp), color = Emerald) { Text("${s.number}", Modifier.padding(10.dp), color = White) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(s.englishName, color = White, fontWeight = FontWeight.Bold); Text("${s.numberOfAyahs} ayat", color = Color.LightGray, fontSize = 12.sp) }; Text(s.name, color = Gold, fontSize = 21.sp) } } }
        }
    }
}

private const val BISMILLAH = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ"

private fun removeLeadingBismillah(text: String): String {
    val original = text.replace("\uFEFF", "").trim()
    fun plainArabic(value: String): String = value
        .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        .replace("\\u0640", "")
        .replace(Regex("\\s+"), "")
        .trim()

    val target = plainArabic(BISMILLAH)
    val originalChars = original.toCharArray()
    var i = 0
    var j = 0
    while (i < originalChars.size && j < target.length) {
        val c = originalChars[i]
        if (c.isWhitespace() || c in '\u064B'..'\u065F' || c == '\u0670' || c == '\u0640') {
            i++
            continue
        }
        if (c != target[j]) return original
        i++
        j++
    }
    return if (j == target.length) original.substring(i).trim() else original
}

@Composable
fun ReaderScreen(s: SurahDetail, onBack: () -> Unit) {
    var selectedQari by remember { mutableStateOf(QARI_LIST.first()) }

    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("alquran", Context.MODE_PRIVATE) }
    var bookmarks by remember { mutableStateOf(prefs.getStringSet("bookmarks", emptySet()) ?: emptySet()) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Column { Text(s.englishName, color = White, fontWeight = FontWeight.Bold); Text("${s.numberOfAyahs} ayat", color = Color.Gray, fontSize = 12.sp) }
        }
        
        var qariExpanded by remember { mutableStateOf(false) }
        Text(
            "Qari Murattal",
            color = Gold,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 14.dp)
        )
        Box(Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
            OutlinedButton(
                onClick = { qariExpanded = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Pilih Qari: ${selectedQari.name}", color = White)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.ArrowDropDown, contentDescription = "Pilih qari")
            }
            DropdownMenu(
                expanded = qariExpanded,
                onDismissRequest = { qariExpanded = false }
            ) {
                QARI_LIST.forEach { qari ->
                    DropdownMenuItem(
                        text = { Text(qari.name) },
                        onClick = {
                            selectedQari = qari
                            qariExpanded = false
                        }
                    )
                }
            }
        }
        FullSurahMurattalButton(
            globalAyahNumbers = s.ayahs.map { it.number },
            qari = selectedQari
        )
        Spacer(Modifier.height(8.dp))

LazyColumn(Modifier.padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text(tidyArabic(s.name), color = Gold, fontSize = 28.sp, lineHeight = 50.sp, fontFamily = QuranFontFamily, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp)) }
            items(s.ayahs) { a ->
                val key = "${s.number}:${a.numberInSurah}"
                val marked = bookmarks.contains(key)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (a.numberInSurah == 1 && s.number != 9) {
                        Card(colors = CardDefaults.cardColors(containerColor = Surface2), shape = RoundedCornerShape(18.dp)) {
                            Text(tidyArabic(BISMILLAH), color = Gold, fontSize = 27.sp, lineHeight = 50.sp, fontFamily = QuranFontFamily, letterSpacing = 0.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(18.dp))
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            val displayedAyah = if (a.numberInSurah == 1 && s.number != 9) removeLeadingBismillah(a.text) else a.text
                            Text(tidyArabic(displayedAyah), color = White, fontSize = 26.sp, lineHeight = 52.sp, fontFamily = QuranFontFamily, letterSpacing = 0.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text("${a.numberInSurah}", color = Gold, fontSize = 12.sp)
                                Spacer(Modifier.weight(1f))
                                IconButton(onClick = { val set = bookmarks.toMutableSet(); if (marked) set.remove(key) else set.add(key); bookmarks = set; prefs.edit().putStringSet("bookmarks", set).apply() }) {
                                    Icon(if (marked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = Gold)
                                }
                                IconButton(onClick = { val share = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${displayedAyah}\n\nQS ${s.englishName} ayat ${a.numberInSurah}") }; context.startActivity(Intent.createChooser(share, "Bagikan ayat")) }) {
                                    Icon(Icons.Default.Share, null)
                                }
                            }
                                MurattalButton(a.number, selectedQari)
                        }
                    }
                }
            }
        }
    }
}
@Composable
fun FeatureMenu(onOpen: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Fitur Muslim", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("Semua fitur di bawah dapat digunakan langsung.", color = Color.Gray) }
        val list = listOf("🕌" to ("Jadwal Salat" to "prayer"), "🧭" to ("Arah Kiblat" to "qibla"), "📿" to ("Tasbih Digital" to "tasbih"), "🤲" to ("Doa Harian" to "doa"), "📅" to ("Kalender Hijriah" to "calendar"))
        list.forEach { (icon, pair) -> item { Card(Modifier.fillMaxWidth().clickable { onOpen(pair.second) }, colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Text(icon, fontSize = 25.sp); Spacer(Modifier.width(14.dp)); Text(
                        pair.first,
color = White, fontSize = 17.sp); Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null) } } } }
    }
}

@Composable
fun PrayerScreen(vm: PrayerViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }
    val muslimProUrl = "https://app.muslimpro.com/id/prayer-times/indonesia/jakarta-prayer-times/1642911"

    SimplePage("🕌 Jadwal Salat", onBack) {
        Text("Jadwal Salat dari Muslim Pro", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Sumber waktu salat: situs resmi Muslim Pro. Jadwal mengikuti data lokasi Jakarta.", color = Color.LightGray, fontSize = 13.sp)
        OutlinedButton(onClick = { webView?.reload() }) {
            Icon(Icons.Default.Refresh, null)
            Spacer(Modifier.width(6.dp))
            Text("Perbarui Jadwal")
        }
        AndroidView(
            modifier = Modifier.fillMaxWidth().weight(1f),
            factory = { ctx ->
                WebView(ctx).apply {
                    webView = this
                    webViewClient = WebViewClient()
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.cacheMode = WebSettings.LOAD_DEFAULT
                    loadUrl(muslimProUrl)
                }
            },
            update = { webView = it }
        )
    }
}
@Composable fun PrayerRow(name: String, time: String) { Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(14.dp)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(name, color = White, modifier = Modifier.weight(1f)); Text(time, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp) } } }

@Composable
fun QiblaScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var permission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        )
    }
    var qibla by remember { mutableFloatStateOf(0f) }
    var heading by remember { mutableFloatStateOf(0f) }
    var lat by remember { mutableStateOf<Double?>(null) }
    var lon by remember { mutableStateOf<Double?>(null) }
    var sensorReady by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permission =
            result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    }

    fun updateLocation() {
        if (!permission) return
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            val location =
                lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (location != null) {
                lat = location.latitude
                lon = location.longitude
                qibla = bearingToKaaba(location.latitude, location.longitude)
            }
        } catch (_: SecurityException) {
        }
    }

    LaunchedEffect(permission) {
        if (permission) updateLocation()
    }

    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotation = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val listener = object : SensorEventListener {
            private val rotationMatrix = FloatArray(9)
            private val orientation = FloatArray(3)

            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                SensorManager.getOrientation(rotationMatrix, orientation)
                heading = ((Math.toDegrees(orientation[0].toDouble()) + 360.0) % 360.0).toFloat()
                sensorReady = true
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        if (rotation != null) {
            sm.registerListener(listener, rotation, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { sm.unregisterListener(listener) }
    }

    val relative = ((qibla - heading + 540f) % 360f) - 180f
    val aligned = kotlin.math.abs(relative) <= 8f

    SimplePage("🧭 Arah Kiblat", onBack) {
        Text(
            "Kiblat jadi mudah",
            color = Gold,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Izinkan lokasi, lalu putar HP sampai panah menunjuk ke arah Ka'bah.",
            color = Color.LightGray,
            fontSize = 14.sp,
            lineHeight = 21.sp
        )

        if (!permission) {
            Button(
                onClick = {
                    launcher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Emerald)
            ) {
                Icon(Icons.Default.LocationOn, null)
                Spacer(Modifier.width(8.dp))
                Text("Izinkan Lokasi")
            }
        } else {
            OutlinedButton(
                onClick = { updateLocation() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Refresh, null)
                Spacer(Modifier.width(8.dp))
                Text("Perbarui Lokasi")
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Surface2),
            shape = RoundedCornerShape(26.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    if (aligned) "✓ Menghadap Kiblat" else "Arahkan ke Kiblat",
                    color = if (aligned) Gold else White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                Box(
                    modifier = Modifier.size(240.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        shape = CircleShape,
                        color = Deep
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                "N",
                                color = Gold,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopCenter).padding(top = 14.dp)
                            )
                            Text(
                                "↑",
                                color = Gold,
                                fontSize = 86.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.rotate(relative)
                            )
                            Text(
                                "🕋",
                                fontSize = 31.sp,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "${kotlin.math.round(relative).toInt()}°",
                    color = White,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "putar HP mengikuti arah panah",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Surface),
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Status", color = Gold, fontWeight = FontWeight.Bold)
                Text(
                    if (lat != null) "Lokasi: ${lat!!.format(4)}, ${lon!!.format(4)}"
                    else "Lokasi belum tersedia — tekan Perbarui Lokasi.",
                    color = White
                )
                Text(
                    if (sensorReady) "Sensor kompas: aktif" else "Sensor kompas: belum tersedia",
                    color = if (sensorReady) Color.LightGray else Gold,
                    fontSize = 13.sp
                )
                Text(
                    if (qibla > 0f) "Arah Kiblat: ${qibla.toInt()}° dari utara"
                    else "Arah Kiblat: menunggu lokasi",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            }
        }

        Text(
            "Tips: jauhkan HP dari magnet, casing magnet, atau benda logam saat mengkalibrasi kompas.",
            color = Color.Gray,
            fontSize = 12.sp,
            lineHeight = 18.sp
        )
    }
}

fun bearingToKaaba(lat: Double, lon: Double): Float {
    val kaabaLat = Math.toRadians(21.422487); val kaabaLon = Math.toRadians(39.826206); val p1 = Math.toRadians(lat); val l1 = Math.toRadians(lon); val dl = kaabaLon - l1
    return ((Math.toDegrees(Math.atan2(Math.sin(dl), Math.cos(p1) * Math.tan(kaabaLat) - Math.sin(p1) * Math.cos(dl))) + 360) % 360).toFloat()
}

@Composable
fun TasbihScreen(onBack: () -> Unit) {
    val context = LocalContext.current; val prefs = remember { context.getSharedPreferences("tasbih", Context.MODE_PRIVATE) }
    var count by remember { mutableIntStateOf(prefs.getInt("count", 0)) }; var target by remember { mutableIntStateOf(prefs.getInt("target", 33)) }; var phrase by remember { mutableStateOf(prefs.getString("phrase", "سُبْحَانَ اللَّهِ") ?: "سُبْحَانَ اللَّهِ") }
    fun save() = prefs.edit().putInt("count", count).putInt("target", target).putString("phrase", phrase).apply()
    SimplePage("📿 Tasbih Digital", onBack) {
        Text(phrase, color = Gold, fontSize = 25.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text("$count", color = White, fontSize = 70.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Text("Target $target", color = Color.Gray, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Button(onClick = { count = if (count >= target) 0 else count + 1; save() }, modifier = Modifier.fillMaxWidth().height(64.dp), colors = ButtonDefaults.buttonColors(containerColor = Emerald)) { Text("TASBIH", fontSize = 20.sp) }
        OutlinedButton(onClick = { count = 0; save() }, modifier = Modifier.fillMaxWidth()) { Text("Reset") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(33, 99, 100).forEach { n -> FilterChip(selected = target == n, onClick = { target = n; count = 0; save() }, label = { Text("$n") }) } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("سُبْحَانَ اللَّهِ", "الْحَمْدُ لِلَّهِ", "اللَّهُ أَكْبَرُ").forEach { p -> FilterChip(selected = phrase == p, onClick = { phrase = p; save() }, label = { Text(p, fontSize = 11.sp) }) } }
    }
}


@Composable
fun FullSurahMurattalButton(
    globalAyahNumbers: List<Int>,
    qari: Qari
) {
    var playing by remember(qari.id, globalAyahNumbers) { mutableStateOf(false) }
    val mp = remember { MurattalPlayer() }

    DisposableEffect(Unit) {
        onDispose { mp.stop() }
    }

    Button(
        onClick = {
            if (playing) {
                mp.stop()
                playing = false
            } else {
                playing = true
                mp.playSurah(
                    globalAyahNumbers = globalAyahNumbers,
                    qari = qari,
                    onFinished = { playing = false },
                    onError = { playing = false }
                )
            }
        },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Surface2)
    ) {
        Text(
            if (playing) "⏹ Hentikan Murattal" else "▶ Putar 1 Surah Sampai Selesai",
            color = Gold,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun MurattalButton(globalAyahNumber: Int, qari: Qari) {
    var playing by remember(qari.id, globalAyahNumber) { mutableStateOf(false) }
    var loading by remember(qari.id, globalAyahNumber) { mutableStateOf(false) }
    var error by remember(qari.id, globalAyahNumber) { mutableStateOf<String?>(null) }
    val mp = remember { MurattalPlayer() }

    DisposableEffect(Unit) {
        onDispose { mp.stop() }
    }

    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Button(
            onClick = {
                error = null
                if (playing || loading) {
                    mp.stop()
                    playing = false
                    loading = false
                } else {
                    loading = true
                    mp.play(
                        globalAyahNumber = globalAyahNumber,
                        qari = qari,
                        onStarted = {
                            loading = false
                            playing = true
                        },
                        onFinished = {
                            loading = false
                            playing = false
                        },
                        onError = {
                            loading = false
                            playing = false
                            error = it
                        }
                    )
                }
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Surface2)
        ) {
            Text(
                when {
                    loading -> "Memuat…"
                    playing -> "⏹ Berhenti"
                    else -> "▶ Murattal"
                },
                color = Gold,
                fontWeight = FontWeight.Bold
            )
        }

        if (error != null) {
            Text(error!!, color = Color(0xFFFF9E9E), fontSize = 11.sp)
        }
    }
}


@Composable
fun DoaScreen(onBack: () -> Unit) {
    val doa = COMPLETE_DAILY_DUAS

    SimplePage("🤲 Doa Harian", onBack) {
        Text("Kumpulan doa keseharian yang umum digunakan.", color = Color.LightGray, fontSize = 14.sp, lineHeight = 21.sp)
        doa.forEachIndexed { index, dua ->
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(modifier = Modifier.size(32.dp), shape = CircleShape, color = Surface2) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("${index + 1}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(dua.title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Text(
                        pair.first,
                        color = White,
                        fontSize = 24.sp,
                        lineHeight = 48.sp,
                        fontFamily = QuranFontFamily,
                        letterSpacing = 0.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(dua.latin, color = Color.LightGray, fontSize = 13.sp, lineHeight = 20.sp)
                    Spacer(Modifier.height(7.dp))
                    Text(dua.meaning, color = Color.LightGray, fontSize = 14.sp, lineHeight = 21.sp)
                }
            }
        }
    }
}

@Composable
fun HijriScreen(vm: PrayerViewModel, onBack: () -> Unit) {
    val date = SimpleDateFormat("dd MMMM yyyy", Locale("id", "ID")).format(Date())
    LaunchedEffect(Unit) { vm.loadHijri() }
    SimplePage("📅 Kalender Hijriah", onBack) {
        Text("Hari ini", color = Color.Gray)
        Text(date, color = White, fontSize = 23.sp)
        Text(vm.hijri, color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Kalender Hijriah", color = Gold, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Konversi tanggal Masehi ke Hijriah diperbarui dari layanan AlAdhan.", color = Color.LightGray)
                Spacer(Modifier.height(8.dp))
                Text("Catatan: awal bulan Hijriah dapat berbeda menurut metode/rukyah setempat.", color = Color.Gray, fontSize = 12.sp)
            }
        }
        OutlinedButton(onClick = { vm.loadHijri() }) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Perbarui Tanggal") }
    }
}

@Composable
fun SimplePage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Deep)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, null, tint = White)
            }
            Text(
                title,
                color = White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Column(
            Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

fun Double.format(decimals: Int): String = String.format(Locale.US, "%.${decimals}f", this)
