# Al-Qur'an Digital

Aplikasi Android Al-Qur'an Digital dengan fitur:

- Al-Qur'an 114 surah dari API AlQuran.cloud
- Pencarian surah
- Pembaca ayat Arab/Utsmani
- Bookmark ayat tersimpan di perangkat
- Bagikan ayat
- Jadwal salat berdasarkan lokasi perangkat
- Arah kiblat berdasarkan koordinat + sensor kompas
- Tasbih digital dengan target 33/99/100 dan penyimpanan otomatis
- Doa harian Arab + terjemahan Indonesia
- Konversi tanggal Masehi ke Hijriah

## Build

Project sengaja tidak menyertakan GitHub Actions workflow. Workflow dapat diletakkan terpisah di `.github/workflows/build-apk.yml`.
