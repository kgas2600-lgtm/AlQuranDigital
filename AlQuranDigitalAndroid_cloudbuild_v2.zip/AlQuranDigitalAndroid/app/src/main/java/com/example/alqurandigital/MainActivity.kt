package com.example.alqurandigital

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.android.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.client.request.*

private val Emerald = Color(0xFF0B6B4F)
private val Deep = Color(0xFF071A13)
private val Gold = Color(0xFFD8B15A)

@Serializable data class Surah(val number:Int, val name:String, val englishName:String, val numberOfAyahs:Int)
@Serializable data class Edition(val identifier:String, val language:String, val name:String, val englishName:String, val format:String, val type:String)
@Serializable data class Ayah(val number:Int, val text:String, val numberInSurah:Int)
@Serializable data class SurahDetail(val number:Int, val name:String, val englishName:String, val numberOfAyahs:Int, val ayahs:List<Ayah>)
@Serializable data class ApiResponse<T>(val code:Int, val status:String, val data:T)

class QuranViewModel : ViewModel() {
    private val client = HttpClient(Android) { install(ContentNegotiation) { json() } }
    var surahs by mutableStateOf<List<Surah>>(emptyList()); private set
    var selected by mutableStateOf<SurahDetail?>(null)
    var loading by mutableStateOf(false); private set
    var error by mutableStateOf<String?>(null); private set
    var query by mutableStateOf("")

    init { loadSurahs() }

    fun loadSurahs() = viewModelScope.launch {
        loading = true; error = null
        try { surahs = client.get("https://api.alquran.cloud/v1/surah").body<ApiResponse<List<Surah>>>().data }
        catch(e: Exception) { error = "Gagal memuat Al-Qur'an. Periksa koneksi internet." }
        loading = false
    }
    fun openSurah(number:Int) = viewModelScope.launch {
        loading = true; error = null
        try { selected = client.get("https://api.alquran.cloud/v1/surah/$number/quran-uthmani").body<ApiResponse<SurahDetail>>().data }
        catch(e: Exception) { error = "Surah gagal dimuat." }
        loading = false
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Emerald, secondary = Gold, background = Deep, surface = Color(0xFF10261E)
    ), content = content)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { QuranApp() } }
    }
}

@Composable
fun QuranApp(vm: QuranViewModel = androidx.lifecycle.viewmodel.compose.viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Deep,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D211A)) {
                listOf("Beranda","Al-Qur'an","Bookmark","Fitur").forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(if(i==0) Icons.Default.Home else if(i==1) Icons.Default.MenuBook else if(i==2) Icons.Default.Bookmark else Icons.Default.Explore, null) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (vm.selected != null) SurahScreen(vm.selected!!, onBack={vm.selected=null})
            else when(tab) {
                0 -> HomeScreen(onRead={tab=1})
                1 -> QuranScreen(vm)
                2 -> BookmarkScreen()
                else -> FeatureScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(onRead:()->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        item {
            Text("السَّلَامُ عَلَيْكُمْ", color=Gold, fontSize=18.sp)
            Text("Al-Qur'an Digital", color=Color.White, fontSize=30.sp, fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Card(shape=RoundedCornerShape(24.dp), colors=CardDefaults.cardColors(containerColor=Emerald)) {
                Column(Modifier.padding(22.dp)) {
                    Text("بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ", fontSize=26.sp, textAlign=TextAlign.Center, modifier=Modifier.fillMaxWidth())
                    Spacer(Modifier.height(14.dp))
                    Text("Bacalah Al-Qur'an dengan tenang dan penuh penghayatan.", color=Color.White.copy(.9f))
                    Spacer(Modifier.height(18.dp))
                    Button(onClick=onRead, colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=Deep)) {
                        Icon(Icons.Default.MenuBook,null); Spacer(Modifier.width(8.dp)); Text("Mulai Membaca")
                    }
                }
            }
        }
        item { Text("Akses Cepat", color=Color.White, fontSize=20.sp, fontWeight=FontWeight.Bold) }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.fillMaxWidth()) {
                Box(Modifier.weight(1f)) { Quick("📖","30 Juz") }
                Box(Modifier.weight(1f)) { Quick("🔖","Bookmark") }
                Box(Modifier.weight(1f)) { Quick("🤲","Doa") }
                Box(Modifier.weight(1f)) { Quick("📿","Tasbih") }
            }
        }
    }
}
@Composable fun Quick(icon:String,text:String){ Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF10261E)), shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,fontSize=25.sp);Text(text,fontSize=12.sp)}}}

@Composable
fun QuranScreen(vm: QuranViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Al-Qur'an", color=Color.White, fontSize=28.sp, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value=vm.query,onValueChange={vm.query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Cari surah...")},leadingIcon={Icon(Icons.Default.Search,null)})
        Spacer(Modifier.height(12.dp))
        val filtered = vm.surahs.filter { it.englishName.contains(vm.query,true) || it.name.contains(vm.query,true) || it.number.toString()==vm.query }
        if(vm.loading && vm.surahs.isEmpty()) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        if(vm.error!=null) Text(vm.error!!, color=Color(0xFFFFB4AB), modifier=Modifier.padding(12.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(filtered) { s ->
                Card(Modifier.fillMaxWidth().clickable{vm.openSurah(s.number)}, colors=CardDefaults.cardColors(containerColor=Color(0xFF10261E)), shape=RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically) {
                        Surface(shape=RoundedCornerShape(12.dp),color=Emerald){Text("${s.number}",Modifier.padding(10.dp),color=Color.White)}
                        Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)){Text(s.englishName,color=Color.White,fontWeight=FontWeight.Bold);Text("${s.numberOfAyahs} ayat",color=Color.LightGray,fontSize=12.sp)}
                        Text(s.name,color=Gold,fontSize=22.sp)
                    }
                }
            }
        }
    }
}
@Composable
fun SurahScreen(s:SurahDetail,onBack:()->Unit){
    Column(Modifier.fillMaxSize()){
        Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)};Column{Text(s.englishName,color=Color.White,fontWeight=FontWeight.Bold);Text("${s.numberOfAyahs} ayat",color=Color.Gray,fontSize=12.sp)}}
        LazyColumn(Modifier.padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{Text(s.name,color=Gold,fontSize=30.sp,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth().padding(12.dp))}
            items(s.ayahs){a->Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF10261E)),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Text(a.text,color=Color.White,fontSize=25.sp,lineHeight=42.sp,textAlign=TextAlign.Right,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));Row(verticalAlignment=Alignment.CenterVertically){Text("${a.numberInSurah}",color=Gold,fontSize=12.sp);Spacer(Modifier.weight(1f));IconButton(onClick={}){Icon(Icons.Default.BookmarkBorder,null)};IconButton(onClick={}){Icon(Icons.Default.Share,null)}}}}}
        }
    }
}
@Composable fun BookmarkScreen(){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("🔖\n\nBelum ada bookmark",color=Color.White,textAlign=TextAlign.Center,fontSize=18.sp)}}
@Composable fun FeatureScreen(){LazyColumn(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Fitur Muslim",color=Color.White,fontSize=28.sp,fontWeight=FontWeight.Bold)};listOf("🕌 Jadwal Salat","🧭 Arah Kiblat","📿 Tasbih Digital","🤲 Doa Harian","📅 Kalender Hijriah","🌙 Pengaturan Tampilan").forEach{label->item{Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFF10261E)),shape=RoundedCornerShape(16.dp)){Text(label,Modifier.padding(18.dp),color=Color.White,fontSize=17.sp)}}}}}
