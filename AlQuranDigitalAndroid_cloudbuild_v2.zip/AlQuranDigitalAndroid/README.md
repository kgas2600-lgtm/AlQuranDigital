# Al-Qur'an Digital — Android

Project starter Android (Kotlin + Jetpack Compose) dengan UI Islamic premium.
Fitur aktif pada versi awal: daftar 114 surah, pencarian surah, pembaca ayat Arab Utsmani, bookmark UI, dan menu fitur Muslim.

## Build
Buka folder ini di Android Studio, lakukan Gradle Sync, lalu Build > Build APK(s).

Catatan: data Qur'an pada versi awal diambil dari API AlQuran.cloud sehingga membutuhkan internet. Audio murottal, terjemahan, bookmark persisten, jadwal salat, kiblat, doa, dan kalender dapat dilanjutkan pada versi berikutnya.
